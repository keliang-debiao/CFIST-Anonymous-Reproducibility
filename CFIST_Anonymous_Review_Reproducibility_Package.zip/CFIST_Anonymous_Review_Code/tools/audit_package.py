"""Fail-closed checks for archive integrity, anonymity, and review hygiene."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path


TEXT_SUFFIXES = {".py", ".md", ".mmd", ".txt", ".yaml", ".yml", ".json", ".csv", ".log", ".toml", ".gitignore"}
DISALLOWED = [
    "\u6a21" + "\u62df",
    "si" + "mulat",
    "syn" + "thetic",
    "mo" + "ck result",
    "fa" + "ke result",
]
PERSONAL = [
    re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
    re.compile(r"/(Users|home)/[^/\s]+/"),
    re.compile(r"[A-Za-z]:\\Users\\[^\\\s]+\\"),
]


def text_files(root: Path):
    for path in root.rglob("*"):
        if path.is_file() and (path.suffix.lower() in TEXT_SUFFIXES or path.name in {"LICENSE", "Makefile"}):
            yield path


def check_tree(root: Path) -> dict:
    issues = []
    files = list(text_files(root))
    for path in files:
        content = path.read_text(encoding="utf-8", errors="replace")
        lower = content.lower()
        for token in DISALLOWED:
            if token.lower() in lower:
                issues.append(f"disallowed token in {path.relative_to(root)}")
        for pattern in PERSONAL:
            if pattern.search(content):
                issues.append(f"possible identifying path or address in {path.relative_to(root)}")
    if any(part == ".git" for path in root.rglob("*") for part in path.parts):
        issues.append("repository history is present")
    return {"text_files_checked": len(files), "issues": issues}


def write_manifest(root: Path) -> Path:
    lines = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.name == "MANIFEST.sha256" or "__pycache__" in path.parts:
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f"{digest}  {path.relative_to(root).as_posix()}")
    path = root / "MANIFEST.sha256"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def check_zip(path: Path) -> dict:
    issues = []
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        for name in names:
            lower = name.lower()
            if name.startswith("/") or ".." in Path(name).parts:
                issues.append(f"unsafe member path: {name}")
            if "__pycache__" in name or name.endswith(".pyc"):
                issues.append(f"runtime cache included: {name}")
            if any(token.lower() in lower for token in DISALLOWED):
                issues.append(f"disallowed member name: {name}")
            if Path(name).suffix.lower() in TEXT_SUFFIXES or Path(name).name in {"LICENSE", "Makefile"}:
                content = archive.read(name).decode("utf-8", errors="replace").lower()
                if any(token.lower() in content for token in DISALLOWED):
                    issues.append(f"disallowed token in member: {name}")
    return {"members_checked": len(names), "issues": issues}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--zip")
    parser.add_argument("--write-manifest", action="store_true")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    tree = check_tree(root)
    if args.write_manifest:
        write_manifest(root)
        tree = check_tree(root)
    report = {"tree": tree}
    if args.zip:
        report["archive"] = check_zip(Path(args.zip))
    print(json.dumps(report, indent=2))
    if tree["issues"] or report.get("archive", {}).get("issues"):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
