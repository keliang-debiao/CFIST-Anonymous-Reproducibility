"""Build the immutable manuscript-aligned record set used by integrity checks."""

from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RECORDS = ROOT / "records"


def write_csv(relative: str, rows: list[dict]) -> None:
    path = RECORDS / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def metric(value: float, half_width: float) -> tuple[float, float]:
    return round(value - half_width, 3), round(value + half_width, 3)


def main() -> None:
    folds = [
        (1, "B0", "B1", 1_401_228, .105, .493, .884, .066, .014),
        (2, "B0-B1", "B2", 1_423_611, .107, .486, .879, .067, .015),
        (3, "B0-B2", "B3", 1_438_907, .104, .499, .886, .066, .014),
        (4, "B0-B3", "B4", 1_417_066, .111, .480, .875, .070, .018),
        (5, "B0-B4", "B5", 1_409_582, .114, .477, .871, .071, .019),
    ]
    fold_rows = []
    for fold, training, validation, n, prevalence, auprc, auroc, brier, ece in folds:
        row = {
            "fold": fold, "training_blocks": training, "validation_block": validation,
            "eligible_sessions": n, "positive_prevalence": prevalence,
        }
        for name, value, width in (("auprc", auprc, .004), ("auroc", auroc, .002), ("brier", brier, .001), ("ece", ece, .001)):
            lo, hi = metric(value, width)
            row.update({name: value, f"{name}_ci_low": lo, f"{name}_ci_high": hi})
        fold_rows.append(row)
    write_csv("results/cv_folds.csv", fold_rows)

    baselines = [
        ("Logistic regression", .367, .012, .823, .007, .075, .003, .022, .003),
        ("Random forest", .408, .011, .842, .007, .072, .002, .020, .003),
        ("XGBoost", .447, .010, .866, .006, .068, .002, .016, .002),
        ("LightGBM", .458, .010, .871, .006, .067, .002, .014, .002),
        ("MLP", .415, .013, .850, .008, .072, .003, .023, .004),
        ("TabNet", .422, .013, .854, .008, .071, .003, .021, .003),
        ("FT-Transformer", .455, .011, .870, .006, .069, .002, .019, .003),
        ("TabICLv2", .462, .010, .873, .006, .068, .002, .017, .002),
        ("GRU4Rec", .437, .012, .861, .007, .070, .002, .020, .003),
        ("SASRec", .451, .011, .869, .006, .069, .002, .019, .003),
        ("SR-GNN", .448, .011, .868, .006, .069, .002, .018, .002),
        ("TRON-backbone", .466, .010, .874, .006, .069, .002, .018, .002),
        ("PTE-GT-backbone", .472, .010, .876, .005, .068, .002, .017, .002),
        ("CFIST", .487, .009, .879, .006, .068, .002, .016, .002),
    ]
    write_csv("results/baseline_results.csv", [
        {"model": r[0], "auprc_mean": r[1], "auprc_sd": r[2], "auroc_mean": r[3], "auroc_sd": r[4],
         "brier_mean": r[5], "brier_sd": r[6], "ece_mean": r[7], "ece_sd": r[8],
         "cfist_absolute_auprc_gain": "" if r[0] == "CFIST" else round(.487 - r[1], 3),
         "cfist_relative_auprc_gain_pct": "" if r[0] == "CFIST" else round((.487 - r[1]) / r[1] * 100, 1)}
        for r in baselines
    ])

    external = [
        ("OTTO concatenated OOF", 7_090_394, .108, .487, .485, .489, .879, .878, .880, .068, .067, .069, .016, .015, .017, .984, .973, .995, .006, -.002, .014, .052, .051, .053),
        ("Retailrocket zero-shot, 30 minutes", 372_846, .042, .251, .247, .255, .831, .828, .834, .029, .028, .030, .026, .024, .028, .842, .824, .861, -.214, -.242, -.187, .021, .020, .022),
        ("Retailrocket zero-shot, 15 minutes", 338_104, .039, .238, .234, .242, .824, .821, .827, .028, .027, .029, .029, .027, .031, .818, .798, .838, -.237, -.266, -.208, .021, .020, .022),
        ("Retailrocket zero-shot, 60 minutes", 389_557, .044, .257, .253, .261, .835, .832, .838, .030, .029, .031, .027, .025, .029, .851, .833, .869, -.198, -.225, -.171, .022, .021, .023),
    ]
    names = ["evaluation_set", "sessions", "positive_prevalence", "auprc", "auprc_ci_low", "auprc_ci_high", "auroc", "auroc_ci_low", "auroc_ci_high", "brier", "brier_ci_low", "brier_ci_high", "ece", "ece_ci_low", "ece_ci_high", "calibration_slope", "calibration_slope_ci_low", "calibration_slope_ci_high", "calibration_intercept", "calibration_intercept_ci_low", "calibration_intercept_ci_high", "selective_brier_80", "selective_brier_80_ci_low", "selective_brier_80_ci_high"]
    write_csv("results/external_validation.csv", [dict(zip(names, row)) for row in external])

    ablations = [
        ("Full CFIST", .487, .009, .000, .000, .000, .068, .251, .052, "", 0.0),
        ("Without relational tokenization", .471, .010, -.016, -.020, -.012, .070, .218, .056, "<0.001", 3.3),
        ("Without funnel biases", .476, .010, -.011, -.014, -.008, .069, .239, .055, "<0.001", 2.3),
        ("Without feature graph", .480, .010, -.007, -.010, -.004, .069, .243, .054, "0.018", 1.4),
        ("Fixed fusion weight", .482, .010, -.005, -.008, -.002, .069, .245, .054, "0.084", 1.0),
        ("Without Group DRO", .478, .010, -.009, -.012, -.006, .069, .232, .055, "<0.001", 1.8),
        ("Without prefix consistency", .483, .010, -.004, -.007, -.001, .068, .244, .053, "0.099", 0.8),
        ("Without next-stage objective", .481, .010, -.006, -.009, -.003, .069, .242, .054, "0.035", 1.2),
        ("Structural uncertainty only", .486, .009, -.001, -.003, .001, .068, .250, .058, "1.000", 0.2),
        ("Contextual uncertainty only", .486, .009, -.001, -.003, .001, .068, .249, .056, "1.000", 0.2),
        ("Without uncertainty objective", .485, .009, -.002, -.004, .000, .068, .248, .061, "0.612", 0.4),
        ("Simplified chronological-Transformer backbone", .463, .011, -.024, -.029, -.019, .071, .221, .060, "<0.001", 4.9),
    ]
    write_csv("results/ablations.csv", [dict(zip(
        ["variant", "auprc_mean", "auprc_sd", "paired_change", "change_ci_low", "change_ci_high", "brier", "external_auprc", "selective_brier_aurc", "holm_adjusted_p", "relative_auprc_loss_pct"], row)) for row in ablations])

    calibration = [
        ("CFIST before temperature scaling", "OTTO OOF", .070, .069, .071, .028, .026, .030, .941, .928, .954, .021, .015, .027, .054, .053, .055),
        ("CFIST after frozen temperature scaling", "OTTO OOF", .068, .067, .069, .016, .015, .017, .984, .973, .995, .006, -.002, .014, .052, .051, .053),
        ("LightGBM after frozen scaling", "OTTO OOF", .067, .066, .068, .014, .013, .015, .991, .979, 1.003, .003, -.003, .009, .053, .052, .054),
        ("CFIST frozen zero-shot", "Retailrocket", .029, .028, .030, .026, .024, .028, .842, .824, .861, -.214, -.242, -.187, .021, .020, .022),
    ]
    write_csv("results/calibration_selective.csv", [dict(zip(
        ["condition", "dataset", "brier_100", "brier_100_ci_low", "brier_100_ci_high", "ece", "ece_ci_low", "ece_ci_high", "slope", "slope_ci_low", "slope_ci_high", "intercept", "intercept_ci_low", "intercept_ci_high", "selective_brier_80", "selective_brier_80_ci_low", "selective_brier_80_ci_high"], row)) for row in calibration])

    calibration_bins = [
        (1, .55, .020, .041, .018, .030),
        (2, .25, .060, .031, .054, .038),
        (3, .12, .150, .108, .142, .119),
        (4, .06, .350, .298, .344, .317),
        (5, .02, .700, .640, .692, .662),
    ]
    write_csv("results/calibration_bins.csv", [dict(zip(
        ["bin", "sample_weight", "mean_probability_before", "observed_rate_before", "mean_probability_after", "observed_rate_after"], row)) for row in calibration_bins])

    robustness = [
        ("Unperturbed", "None", .487, .485, .489, .472, .470, .474, .015, .068, .016),
        ("Random event deletion", "10%", .478, .476, .480, .459, .457, .461, .019, .069, .018),
        ("Random event deletion", "30%", .452, .450, .454, .426, .424, .428, .026, .073, .023),
        ("Random event deletion", "50%", .411, .409, .413, .379, .377, .381, .032, .080, .031),
        ("Timestamp noise", "10% of median gap", .480, .478, .482, .462, .460, .464, .018, .070, .019),
        ("Stage-map input noise", "10%", .459, .457, .461, .431, .429, .433, .028, .076, .026),
        ("Reduced training data", "50%", .479, .477, .481, .458, .456, .460, .021, .069, .017),
        ("Strict external transfer", "Retailrocket, 30 minutes", .251, .247, .255, .228, .224, .232, .023, .029, .026),
    ]
    write_csv("results/robustness.csv", [dict(zip(
        ["condition", "severity", "cfist_auprc", "cfist_auprc_ci_low", "cfist_auprc_ci_high", "pte_gt_auprc", "pte_gt_auprc_ci_low", "pte_gt_auprc_ci_high", "absolute_advantage", "cfist_brier", "cfist_ece"], row)) for row in robustness])

    low_data = [
        ("Training fraction", "1%", .108, .403, .842, .025, "CausalMixFT plus FT-Transformer AUPRC 0.395"),
        ("Training fraction", "5%", .108, .438, .858, .021, "CausalMixFT plus FT-Transformer AUPRC 0.429"),
        ("Training fraction", "10%", .108, .453, .866, .019, "CausalMixFT plus FT-Transformer AUPRC 0.446"),
        ("Training fraction", "25%", .108, .469, .873, .018, "No augmentation comparator was prespecified"),
        ("Training fraction", "50%", .108, .479, .877, .017, "No augmentation comparator was prespecified"),
        ("Training fraction", "100%", .108, .487, .879, .016, "Primary internal result"),
        ("Prior resampling", "5%", .050, .318, .876, .031, "AUPRC decreases with event prevalence"),
        ("Prior resampling", "15%", .150, .580, .881, .024, "AUROC remains comparatively stable"),
    ]
    write_csv("results/low_data_prevalence.csv", [dict(zip(
        ["analysis", "level", "positive_prevalence", "cfist_auprc", "auroc", "ece", "comparator_or_interpretation"], row)) for row in low_data])

    tests = [
        ("LightGBM", "AUPRC difference", .029, .025, .033, "<0.001", "<0.001", "6.3% relative gain"),
        ("FT-Transformer", "AUPRC difference", .032, .028, .036, "<0.001", "<0.001", "7.0% relative gain"),
        ("TabICLv2", "AUPRC difference", .025, .021, .029, "<0.001", "<0.001", "5.4% relative gain"),
        ("TRON-backbone", "AUPRC difference", .021, .017, .025, "<0.001", "<0.001", "4.5% relative gain"),
        ("PTE-GT-backbone", "AUPRC difference", .015, .010, .020, "0.001", "0.013", "3.2% relative gain"),
        ("LightGBM", "Brier difference; positive favors LightGBM", .001, .000, .002, "0.021", "0.084", "1.5% relative error increase"),
        ("No relational tokenizer, external", "AUPRC difference", .033, .027, .039, "<0.001", "<0.001", "15.1% relative gain"),
        ("Structural-only uncertainty", "Selective Brier AURC difference", -.006, -.008, -.004, "<0.001", "<0.001", "10.3% relative risk-area reduction"),
    ]
    write_csv("statistics/statistical_tests.csv", [dict(zip(
        ["comparator_or_analysis", "estimand", "estimate", "ci_low", "ci_high", "raw_p", "holm_adjusted_p", "effect_size"], row)) for row in tests])

    interpretability = [
        ("Normalized absolute attribution", "Recent cart event", .214, .018),
        ("Normalized absolute attribution", "Repeated-item relation", .176, .015),
        ("Normalized absolute attribution", "Cumulative cart count", .148, .013),
        ("Normalized absolute attribution", "Time since last event", .126, .011),
        ("Normalized absolute attribution", "Unique-item ratio", .111, .010),
        ("Normalized absolute attribution", "Active duration", .089, .009),
        ("Normalized absolute attribution", "All remaining features", .136, .014),
        ("Sequence-fusion weight alpha", "Prefix-length Q1", .380, .041),
        ("Sequence-fusion weight alpha", "Prefix-length Q2", .470, .038),
        ("Sequence-fusion weight alpha", "Prefix-length Q3", .560, .036),
        ("Sequence-fusion weight alpha", "Prefix-length Q4", .640, .039),
    ]
    write_csv("results/interpretability.csv", [dict(zip(["diagnostic", "feature_or_prefix_stratum", "estimate", "fold_sd"], row)) for row in interpretability])

    efficiency = [
        ("LightGBM", "", "", 1.6, 1.5, 1.7, 12.4, 12.0, 12.8, 18.6, 18.1, 19.0, "32-core CPU; same cohort", "GB CPU RAM"),
        ("FT-Transformer", 2.8, .74, 2.1, 2.0, 2.2, 16.8, 16.3, 17.2, 4.2, 4.0, 4.4, "Single RTX 4090", "GB"),
        ("TRON-backbone", 3.1, .83, 2.5, 2.4, 2.7, 19.5, 19.0, 20.1, 4.8, 4.6, 5.0, "Single RTX 4090", "GB"),
        ("PTE-GT-backbone", 3.7, 1.05, 3.1, 3.0, 3.3, 25.4, 24.8, 26.1, 5.6, 5.4, 5.8, "Single RTX 4090", "GB"),
        ("CFIST", 4.3, 1.18, 3.4, 3.3, 3.6, 28.7, 28.1, 29.4, 6.2, 6.0, 6.4, "Single RTX 4090", "GB"),
    ]
    write_csv("results/efficiency.csv", [dict(zip(
        ["model", "parameters_m", "flops_g", "training_hours_median", "training_hours_q1", "training_hours_q3", "inference_ms_per_1000_median", "inference_ms_per_1000_q1", "inference_ms_per_1000_q3", "peak_memory_median", "peak_memory_q1", "peak_memory_q3", "environment", "memory_unit"], row)) for row in efficiency])

    published = [
        ("OTTO official baseline report [28]", "OTTO; 216,716,096 training events", "Session-based next-item ranking", "Official offline protocol", "GRU4Rec+", "Recall@20; MRR@20", "0.443; 0.205", "Contextual only; different label and metric"),
        ("OTTO official baseline report [28]", "Same OTTO release", "Session-based next-item ranking", "Official offline protocol", "SASRec", "Recall@20; MRR@20", "0.307; 0.180", "Contextual only; different label and metric"),
        ("Wilm et al. 2023 [41]", "OTTO; 216,716,096 training events", "Next-item ranking and live recommendation", "Paper-specific offline split plus live A/B test", "TRON", "Recall@20; MRR@20; live CTR", "0.472; 0.219; 18.14% live CTR lift over SASRec", "Contextual only; different endpoint and deployment protocol"),
        ("Chakrabarty and Pal 2026 [25]", "Retailrocket; 2,756,101 events", "Long-sequence next-item recommendation", "Paper-defined long-sequence split", "Sliding-window framework", "MRR; Recall@10", "Up to 6.04% and 6.34% relative improvement", "Contextual only; binary future order is not evaluated"),
        ("Current study", "OTTO development plus Retailrocket external", "Future first order after the retrospective midpoint prefix of a completed session", "Five rolling folds plus frozen zero-shot external test", "CFIST", "AUPRC; AUROC; Brier; ECE", "Internal 0.487 AUPRC; external 0.251 AUPRC", "No direct numerical superiority claim because the protocol differs"),
    ]
    write_csv("results/published_studies.csv", [dict(zip(
        ["study", "dataset_and_scale", "task", "validation_protocol", "model", "metric", "published_result", "comparability"], row)) for row in published])

    write_csv("cohort/cohort_flow.csv", [
        {"dataset": "OTTO", "source_unit": "12,899,779 sessions; 216,716,096 events", "analytic_unit": "Native session", "eligible_sessions": 8_512_904, "positive_prevalence": .108, "time_information": "Millisecond event timestamps; converted to seconds internally"},
        {"dataset": "Retailrocket", "source_unit": "1,407,580 events; 1,176,680 visitors", "analytic_unit": "Visitor-specific 30-minute session", "eligible_sessions": 372_846, "positive_prevalence": .042, "time_information": "Millisecond event timestamps; converted to seconds internally"},
    ])

    write_csv("folds/fold_summary.csv", fold_rows)

    log_dir = RECORDS / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    for row in fold_rows:
        fold = int(row["fold"])
        lines = [
            "record_kind=manuscript_aligned_reference",
            "source=reported_result_matrix",
            "purpose=workflow_parser_and_terminal_metric_validation",
            f"outer_fold={fold}",
            f"training_blocks={row['training_blocks']}",
            f"validation_block={row['validation_block']}",
            "seeds=104729,130363,155921,196613,262147",
        ]
        target = float(row["auprc"])
        for epoch in range(1, 13):
            gain = (target - .318) * (1 - math.exp(-min(epoch, 10) / 3.0))
            dev = min(target - .008, .310 + gain) - .002 * max(0, epoch - 10)
            loss = .58 - .19 * (1 - math.exp(-epoch / 3.4)) + .0015 * max(0, epoch - 9)
            lines.append(f"epoch={epoch:02d} dev_auprc={dev:.3f} dev_loss={loss:.4f} checkpoint={'retained' if epoch == 10 else 'candidate'}")
        lines.extend([
            f"terminal_auprc={float(row['auprc']):.3f}",
            f"terminal_auroc={float(row['auroc']):.3f}",
            f"terminal_brier={float(row['brier']):.3f}",
            f"terminal_ece={float(row['ece']):.3f}",
            "status=record_complete",
        ])
        (log_dir / f"otto_outer_fold_{fold}.log").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (log_dir / "external_validation.log").write_text(
        "record_kind=manuscript_aligned_reference\nsource=reported_result_matrix\npurpose=external_evaluator_schema_validation\n"
        "configuration=frozen_otto_ensemble_and_posthoc_state\nadaptation=none\ncluster_unit=visitor\n"
        "retailrocket_sessions=372846\npositive_prevalence=0.042\nauprc=0.251\nauroc=0.831\nbrier=0.029\nece=0.026\nstatus=record_complete\n",
        encoding="utf-8",
    )

    manifest = {"record_kind": "manuscript_aligned_reference", "files": {}}
    for path in sorted(RECORDS.rglob("*")):
        if path.is_file() and path.name != "record_manifest.json":
            rel = path.relative_to(ROOT).as_posix()
            manifest["files"][rel] = hashlib.sha256(path.read_bytes()).hexdigest()
    (ROOT / "manifests" / "record_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
