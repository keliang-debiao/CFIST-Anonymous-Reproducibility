from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from _bootstrap import ROOT


TABLES = {
    5: ("cv_folds.csv", "CFIST performance across five rolling temporal validation folds"),
    6: ("baseline_results.csv", "Five-fold performance of CFIST and baseline models"),
    7: ("external_validation.csv", "Internal and strict zero-shot external-validation matrix"),
    8: ("published_studies.csv", "Published studies using the same public datasets or closely related session tasks"),
    9: ("ablations.csv", "Component and objective ablations of CFIST"),
    10: ("calibration_selective.csv", "Calibration and selective-risk results"),
    11: ("robustness.csv", "Robustness comparison under matched input perturbations"),
    12: ("low_data_prevalence.csv", "Low-data and prevalence-shift analyses"),
    13: ("statistical_tests.csv", "Paired statistical comparisons"),
    14: ("interpretability.csv", "Interpretability and representation diagnostics"),
    15: ("efficiency.csv", "Computational efficiency and reproducibility profile"),
}


def markdown_table(frame: pd.DataFrame) -> str:
    def cell(value) -> str:
        if pd.isna(value):
            return ""
        if isinstance(value, float):
            return f"{value:.3f}"
        return str(value).replace("|", "\\|")

    header = "|" + "|".join(map(str, frame.columns)) + "|"
    rule = "|" + "|".join(["---"] * len(frame.columns)) + "|"
    rows = ["|" + "|".join(cell(value) for value in row) + "|" for row in frame.itertuples(index=False, name=None)]
    return "\n".join([header, rule, *rows])


def locate(root: Path, name: str) -> Path:
    matches = list(root.rglob(name))
    if len(matches) != 1:
        raise FileNotFoundError(f"Expected one {name} under {root}; found {len(matches)}")
    return matches[0]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--records", default="records")
    parser.add_argument("--output", default="outputs/tables")
    args = parser.parse_args()
    records, output = ROOT / args.records, ROOT / args.output
    output.mkdir(parents=True, exist_ok=True)
    index = []
    for number, (filename, title) in TABLES.items():
        frame = pd.read_csv(locate(records, filename))
        stem = f"table_{number:02d}"
        frame.to_csv(output / f"{stem}.csv", index=False, float_format="%.3f")
        markdown = f"**Table {number}. {title}**\n\n{markdown_table(frame)}\n"
        (output / f"{stem}.md").write_text(markdown, encoding="utf-8")
        index.append({"table": number, "title": title, "source": locate(records, filename).relative_to(ROOT).as_posix()})
    pd.DataFrame(index).to_csv(output / "table_index.csv", index=False)
    print(f"Generated {len(TABLES)} tables in {output.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
