from __future__ import annotations

import argparse
import copy
import json
from functools import partial
from pathlib import Path

import numpy as np

from _bootstrap import ROOT
from cfist.config import load_config, save_json, set_global_seed
from cfist.dataset import ParquetSessionIterable, collate_sessions
from cfist.metrics import binary_metrics, risk_coverage_area, selective_brier
from cfist.model import build_model
from cfist.posthoc import FrozenPosthocState
from cfist.prediction_io import write_predictions, write_state
from cfist.preprocessing import fit_preprocessor_from_dataset
from cfist.storage import iter_session_rows
from cfist.training import fit_network, predict


def collect_timestamps(dataset_dir: Path, blocks: set[int]) -> np.ndarray:
    values = [int(row["end_timestamp"]) for row in iter_session_rows(dataset_dir, ["end_timestamp", "block"]) if int(row["block"]) in blocks]
    if not values:
        raise ValueError(f"No sessions found for blocks {sorted(blocks)}")
    return np.asarray(values, dtype=np.int64)


def make_loader(config, dataset_dir, blocks, preprocessor, seed, *, shuffle, at_most=None, after=None, sample_fraction=1.0, sample_seed=0):
    import torch

    dataset = ParquetSessionIterable.create(
        dataset_dir,
        include_blocks=set(blocks),
        preprocessor=preprocessor,
        shuffle_buffer=8192 if shuffle else 1,
        seed=seed,
        end_timestamp_at_most=at_most,
        end_timestamp_after=after,
        sample_fraction=float(sample_fraction),
        sample_seed=int(sample_seed),
    )
    return torch.utils.data.DataLoader(
        dataset,
        batch_size=int(config["optimization"]["batch_size"]),
        num_workers=int(config["project"]["num_workers"]),
        collate_fn=partial(collate_sessions, max_prefix_length=int(config["data"]["max_prefix_length"])),
        pin_memory=True,
        persistent_workers=int(config["project"]["num_workers"]) > 0,
    )


def average_predictions(runs: list[dict[str, np.ndarray]]) -> dict[str, np.ndarray]:
    reference_ids = runs[0]["entity_id"]
    if any(not np.array_equal(run["entity_id"], reference_ids) for run in runs[1:]):
        raise AssertionError("Seed-specific prediction rows are not aligned")
    output = {"entity_id": reference_ids, "group_id": runs[0]["group_id"]}
    for key in runs[0]:
        if key in {"entity_id", "group_id"}:
            continue
        if key in {"label", "prefix_length", "environment"}:
            output[key] = runs[0][key]
        else:
            output[key] = np.mean(np.stack([run[key] for run in runs], axis=0), axis=0)
    output["logit"] = np.log(np.clip(output["probability"], 1e-7, 1 - 1e-7) / np.clip(1 - output["probability"], 1e-7, 1))
    return output


def run_fold(config: dict, fold: int, output_root: Path) -> dict:
    import torch

    selected_path = ROOT / config["paths"]["output_root"] / "selection" / f"fold_{fold}_selected.json"
    if selected_path.exists() and not config.get("selection_applied", False):
        selected = json.loads(selected_path.read_text(encoding="utf-8"))
        config = copy.deepcopy(config)
        config["optimization"].update(selected["optimization"])
        config["selection_applied"] = True
    dataset_dir = ROOT / config["paths"]["otto_processed"]
    historical_blocks = set(range(fold))
    training_fraction = float(config["optimization"].get("training_fraction", 1.0))
    fraction_seed = int(config["optimization"].get("training_fraction_seed", 424242)) + fold
    timestamps = collect_timestamps(dataset_dir, historical_blocks)
    development_cut = int(np.quantile(timestamps, 1.0 - float(config["data"]["development_fraction"]), method="lower"))
    preprocessor = fit_preprocessor_from_dataset(
        dataset_dir,
        include_blocks=historical_blocks,
        fold=fold,
        gap_bins=int(config["data"]["gap_bins"]),
        end_timestamp_at_most=development_cut,
        sample_fraction=training_fraction,
        sample_seed=fraction_seed,
    )
    save_json(preprocessor.to_dict(), output_root / "preprocessing" / f"fold_{fold}.json")

    dev_runs = []
    outer_runs = []
    fitting_runs = []
    for seed in config["seeds"]:
        seed = int(seed)
        set_global_seed(seed, bool(config["project"]["deterministic"]))
        model = build_model(config)
        training_loader = make_loader(config, dataset_dir, historical_blocks, preprocessor, seed, shuffle=True, at_most=development_cut, sample_fraction=training_fraction, sample_seed=fraction_seed)
        development_loader = make_loader(config, dataset_dir, historical_blocks, preprocessor, seed, shuffle=False, after=development_cut)
        model, _ = fit_network(
            model=model,
            training_loader=training_loader,
            development_loader=development_loader,
            config=config,
            preprocessor=preprocessor,
            fold=fold,
            seed=seed,
            output_dir=output_root / "checkpoints",
        )
        device_request = config["project"].get("device", "auto")
        device = torch.device("cuda" if device_request == "auto" and torch.cuda.is_available() else ("cpu" if device_request == "auto" else device_request))
        fitting_loader = make_loader(config, dataset_dir, historical_blocks, preprocessor, seed, shuffle=False, at_most=development_cut, sample_fraction=training_fraction, sample_seed=fraction_seed)
        development_loader = make_loader(config, dataset_dir, historical_blocks, preprocessor, seed, shuffle=False, after=development_cut)
        outer_loader = make_loader(config, dataset_dir, {fold}, preprocessor, seed, shuffle=False)
        fitting_runs.append(predict(model, fitting_loader, device))
        dev_runs.append(predict(model, development_loader, device))
        outer_runs.append(predict(model, outer_loader, device))

    fitting = average_predictions(fitting_runs)
    development = average_predictions(dev_runs)
    outer = average_predictions(outer_runs)
    posthoc = FrozenPosthocState.fit(
        development,
        prototype_predictions=fitting,
        coverage_levels=tuple(config["evaluation"]["coverage_levels"]),
        uncertainty_mode=config.get("posthoc_mode", "dual"),
    )
    evaluated = posthoc.transform(outer)
    write_predictions(evaluated, output_root / "predictions" / f"fold_{fold}_outer.parquet")
    write_state(posthoc, output_root / "calibration" / f"fold_{fold}.json")
    metrics = binary_metrics(outer["label"], evaluated["probability_calibrated"], int(config["evaluation"]["ece_bins"]))
    metrics["fold"] = fold
    metrics["selective_brier_80"] = selective_brier(
        outer["label"], evaluated["probability_calibrated"], evaluated["accepted_0.80"]
    )
    metrics["selective_brier_aurc"] = risk_coverage_area(
        outer["label"], evaluated["probability_calibrated"], evaluated["uncertainty_combined"]
    )
    return metrics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--fold", type=int, choices=range(1, 6))
    args = parser.parse_args()
    config = load_config(ROOT / args.config)
    output_root = ROOT / config["paths"]["output_root"]
    folds = [args.fold] if args.fold else list(range(1, 6))
    results = [run_fold(copy.deepcopy(config), fold, output_root) for fold in folds]
    result_path = output_root / "results" / "cv_folds.json"
    result_path.parent.mkdir(parents=True, exist_ok=True)
    with result_path.open("w", encoding="utf-8") as handle:
        json.dump(results, handle, indent=2)


if __name__ == "__main__":
    main()
