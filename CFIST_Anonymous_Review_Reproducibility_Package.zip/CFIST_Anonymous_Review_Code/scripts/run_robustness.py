from __future__ import annotations

import argparse
import json

from _bootstrap import ROOT
from cfist.config import load_config
from cfist.baselines import build_neural_baseline
from cfist.calibration import TemperatureScaler
from cfist.metrics import binary_metrics
from cfist.model import build_model
from cfist.posthoc import FrozenPosthocState
from cfist.preprocessing import FoldPreprocessor
from cfist.robustness import perturb_collated_batch
from cfist.training import move_batch
from train_cv import make_loader


def main() -> None:
    import numpy as np
    import torch

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--fold", type=int, default=5, choices=range(1, 6))
    parser.add_argument("--model", choices=["CFIST", "PTE-GT-backbone"], default="CFIST")
    parser.add_argument("--condition", choices=["unperturbed", "event_deletion", "timestamp_noise", "stage_noise"], default="event_deletion")
    parser.add_argument("--severity", type=float, default=0.30)
    args = parser.parse_args()
    config = load_config(ROOT / args.config)
    output_root = ROOT / config["paths"]["output_root"]
    with (output_root / "preprocessing" / f"fold_{args.fold}.json").open("r", encoding="utf-8") as handle:
        preprocessor = FoldPreprocessor.from_dict(json.load(handle))
    posthoc = None
    if args.model == "CFIST":
        with (output_root / "calibration" / f"fold_{args.fold}.json").open("r", encoding="utf-8") as handle:
            posthoc = FrozenPosthocState.from_dict(json.load(handle))
        scaler = None
    else:
        baseline_state = output_root / "results" / "baselines" / f"pte-gt-backbone_fold_{args.fold}.json"
        scaler = TemperatureScaler(float(json.loads(baseline_state.read_text(encoding="utf-8"))["temperature"]))
    requested = config["project"].get("device", "auto")
    device = torch.device("cuda" if requested == "auto" and torch.cuda.is_available() else ("cpu" if requested == "auto" else requested))
    seed_runs = []
    dataset_dir = ROOT / config["paths"]["otto_processed"]
    for seed in config["seeds"]:
        if args.model == "CFIST":
            model = build_model(config).to(device)
            checkpoint_path = output_root / "checkpoints" / f"fold_{args.fold}_seed_{int(seed)}.pt"
        else:
            model = build_neural_baseline(args.model, config).to(device)
            checkpoint_path = output_root / "results" / "baselines" / f"pte-gt-backbone_fold_{args.fold}_seed_{int(seed)}.pt"
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
        model.load_state_dict(checkpoint["model_state"])
        loader = make_loader(config, dataset_dir, {args.fold}, preprocessor, int(seed), shuffle=False)
        model.eval()
        collected = {key: [] for key in ["label", "probability", "prefix_length", "environment"]}
        if args.model == "CFIST":
            collected.update({"error_proxy": [], "representation": [], "fusion_weight": []})
        entity_ids, group_ids = [], []
        with torch.inference_mode():
            for batch_index, batch in enumerate(loader):
                entity_ids.extend(batch["entity_id"])
                group_ids.extend(batch["group_id"])
                batch = perturb_collated_batch(batch, args.condition, args.severity, int(seed) + batch_index, preprocessor)
                batch = move_batch(batch, device)
                model_output = model(batch)
                collected["label"].append(batch["label"].cpu().numpy())
                if args.model == "CFIST":
                    collected["probability"].append(model_output.probability.cpu().numpy())
                    collected["error_proxy"].append(model_output.error_proxy.cpu().numpy())
                    collected["representation"].append(model_output.representation.cpu().numpy())
                    collected["fusion_weight"].append(model_output.fusion_weight.cpu().numpy())
                else:
                    collected["probability"].append(torch.sigmoid(model_output).cpu().numpy())
                collected["prefix_length"].append(batch["prefix_length"].cpu().numpy())
                collected["environment"].append(batch["environment"].cpu().numpy())
        run = {key: np.concatenate(value) for key, value in collected.items()}
        run["entity_id"] = np.asarray(entity_ids, dtype=object)
        run["group_id"] = np.asarray(group_ids, dtype=object)
        run["logit"] = np.log(np.clip(run["probability"], 1e-7, 1 - 1e-7) / np.clip(1 - run["probability"], 1e-7, 1))
        seed_runs.append(run)
    from train_cv import average_predictions

    averaged = average_predictions(seed_runs)
    if args.model == "CFIST":
        evaluated = posthoc.transform(averaged)
    else:
        evaluated = dict(averaged)
        evaluated["probability_calibrated"] = scaler.transform_probability(averaged["probability"])
    result = binary_metrics(evaluated["label"], evaluated["probability_calibrated"], int(config["evaluation"]["ece_bins"]))
    result.update({"fold": args.fold, "model": args.model, "condition": args.condition, "severity": args.severity})
    slug = args.model.lower().replace("-", "_")
    path = output_root / "results" / "robustness" / f"{slug}_fold_{args.fold}_{args.condition}_{args.severity:.2f}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)


if __name__ == "__main__":
    main()
