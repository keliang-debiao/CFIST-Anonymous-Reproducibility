from __future__ import annotations

import argparse
import json
from pathlib import Path

from _bootstrap import ROOT
from cfist.config import load_config
from cfist.metrics import binary_metrics, risk_coverage_area, selective_brier
from cfist.model import build_model
from cfist.posthoc import FrozenPosthocState
from cfist.prediction_io import write_predictions
from cfist.preprocessing import FoldPreprocessor
from cfist.statistics import cluster_bootstrap
from cfist.training import predict
from train_cv import average_predictions, make_loader


def main() -> None:
    import numpy as np
    import torch
    from sklearn.metrics import average_precision_score, roc_auc_score

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--inactivity-minutes", type=int)
    args = parser.parse_args()
    config = load_config(ROOT / args.config)
    output_root = ROOT / config["paths"]["output_root"]
    inactivity = args.inactivity_minutes or int(config["data"]["retailrocket_inactivity_minutes"])
    dataset_dir = ROOT / config["paths"]["retailrocket_processed"] / f"{inactivity}min"
    with (output_root / "preprocessing" / "final.json").open("r", encoding="utf-8") as handle:
        preprocessor = FoldPreprocessor.from_dict(json.load(handle))
    with (output_root / "calibration" / "final.json").open("r", encoding="utf-8") as handle:
        posthoc = FrozenPosthocState.from_dict(json.load(handle))

    requested = config["project"].get("device", "auto")
    device = torch.device("cuda" if requested == "auto" and torch.cuda.is_available() else ("cpu" if requested == "auto" else requested))
    runs = []
    for seed in config["seeds"]:
        model = build_model(config).to(device)
        checkpoint = torch.load(output_root / "checkpoints" / f"fold_6_seed_{int(seed)}.pt", map_location=device, weights_only=False)
        model.load_state_dict(checkpoint["model_state"])
        loader = make_loader(config, dataset_dir, {-1}, preprocessor, int(seed), shuffle=False)
        runs.append(predict(model, loader, device))
    ensemble = average_predictions(runs)
    evaluated = posthoc.transform(ensemble)
    write_predictions(evaluated, output_root / "predictions" / f"retailrocket_{inactivity}min.parquet")

    metrics = binary_metrics(
        evaluated["label"], evaluated["probability_calibrated"], int(config["evaluation"]["ece_bins"])
    )
    metrics["selective_brier_80"] = selective_brier(
        evaluated["label"], evaluated["probability_calibrated"], evaluated["accepted_0.80"]
    )
    metrics["selective_brier_aurc"] = risk_coverage_area(
        evaluated["label"], evaluated["probability_calibrated"], evaluated["uncertainty_combined"]
    )
    resamples = int(config["evaluation"]["bootstrap_resamples"])
    seed = int(config["evaluation"]["bootstrap_seed"])
    for name, statistic in {"auprc": average_precision_score, "auroc": roc_auc_score}.items():
        estimate, interval, _ = cluster_bootstrap(
            labels=evaluated["label"],
            predictions=evaluated["probability_calibrated"],
            clusters=evaluated["group_id"],
            statistic=statistic,
            resamples=resamples,
            seed=seed,
        )
        metrics[f"{name}_estimate"] = estimate
        metrics[f"{name}_ci_low"] = interval[0]
        metrics[f"{name}_ci_high"] = interval[1]
    result_path = output_root / "results" / f"external_{inactivity}min.json"
    result_path.parent.mkdir(parents=True, exist_ok=True)
    with result_path.open("w", encoding="utf-8") as handle:
        json.dump(metrics, handle, indent=2)


if __name__ == "__main__":
    main()
