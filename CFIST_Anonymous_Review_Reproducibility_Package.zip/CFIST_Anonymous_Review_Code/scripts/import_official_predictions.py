from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from _bootstrap import ROOT
from cfist.calibration import TemperatureScaler
from cfist.config import load_config
from cfist.metrics import binary_metrics
from cfist.preprocessing import fit_preprocessor_from_dataset
from cfist.storage import iter_session_rows
from run_baselines import load_tabular
from train_cv import collect_timestamps


def main() -> None:
    parser = argparse.ArgumentParser(description="Import predictions produced by an official baseline release without relabeling the estimator.")
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--model", required=True, choices=["TabICLv2"])
    parser.add_argument("--fold", type=int, required=True, choices=range(1, 6))
    parser.add_argument("--development", required=True, help="CSV or Parquet with entity_id and probability_raw")
    parser.add_argument("--outer", required=True, help="CSV or Parquet with entity_id and probability_raw")
    args = parser.parse_args()
    config = load_config(ROOT / args.config)
    dataset_dir = ROOT / config["paths"]["otto_processed"]
    output_root = ROOT / config["paths"]["output_root"]
    historical = set(range(args.fold))
    cut = int(np.quantile(collect_timestamps(dataset_dir, historical), .90, method="lower"))
    preprocessor = fit_preprocessor_from_dataset(dataset_dir, include_blocks=historical, fold=args.fold, gap_bins=int(config["data"]["gap_bins"]), end_timestamp_at_most=cut)
    _, y_dev, id_dev = load_tabular(dataset_dir, historical, preprocessor, after=cut)
    _, y_outer, id_outer = load_tabular(dataset_dir, {args.fold}, preprocessor)

    def read(path, expected_ids, labels):
        path = Path(path)
        frame = pd.read_parquet(path) if path.suffix == ".parquet" else pd.read_csv(path)
        required = {"entity_id", "probability_raw"}
        if not required.issubset(frame.columns):
            raise ValueError(f"{path} must contain {sorted(required)}")
        if frame.entity_id.duplicated().any():
            raise ValueError(f"Duplicate entity identifiers in {path}")
        expected = pd.DataFrame({"entity_id": expected_ids.astype(str), "label": labels})
        merged = expected.merge(frame[["entity_id", "probability_raw"]].assign(entity_id=lambda x: x.entity_id.astype(str)), on="entity_id", validate="one_to_one")
        if len(merged) != len(expected):
            raise ValueError(f"Incomplete identifier coverage in {path}: {len(merged)} of {len(expected)}")
        if not merged.probability_raw.between(0, 1).all():
            raise ValueError(f"Probability outside [0, 1] in {path}")
        return merged

    development = read(args.development, id_dev, y_dev)
    outer = read(args.outer, id_outer, y_outer)
    p_dev = development.probability_raw.to_numpy(float)
    logit = np.log(np.clip(p_dev, 1e-7, 1 - 1e-7) / np.clip(1 - p_dev, 1e-7, 1))
    scaler = TemperatureScaler().fit(logit, development.label.to_numpy())
    calibrated = scaler.transform_probability(outer.probability_raw.to_numpy(float))
    result = binary_metrics(outer.label.to_numpy(), calibrated, int(config["evaluation"]["ece_bins"]))
    result.update({"model": args.model, "fold": args.fold, "source": "official_release_predictions", "temperature": scaler.temperature})
    slug = args.model.lower()
    path = output_root / "results" / "baselines" / f"{slug}_fold_{args.fold}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    pd.DataFrame({
        "entity_id": outer.entity_id, "group_id": outer.entity_id, "label": outer.label,
        "probability_raw": outer.probability_raw, "probability_calibrated": calibrated,
    }).to_parquet(path.with_suffix(".parquet"), index=False, compression="zstd")


if __name__ == "__main__":
    main()
