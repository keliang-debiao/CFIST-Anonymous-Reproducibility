from __future__ import annotations

import argparse
import copy
import json
import subprocess
import sys
from pathlib import Path

from _bootstrap import ROOT
from cfist.config import load_config, save_config
from train_cv import run_fold


ABLATIONS = {
    "full": {},
    "no_relational_tokenization": {"ablation.remove_relational_tokenization": True},
    "no_funnel_biases": {"ablation.remove_funnel_biases": True},
    "no_feature_graph": {"ablation.remove_feature_graph": True},
    "fixed_fusion": {"ablation.fixed_fusion": True},
    "no_group_dro": {"optimization.group_dro_enabled": False},
    "no_prefix_consistency": {"optimization.lambda_prefix": 0.0},
    "no_next_stage_objective": {"optimization.lambda_stage": 0.0},
    "structural_uncertainty_only": {"posthoc_mode": "structural"},
    "contextual_uncertainty_only": {"posthoc_mode": "contextual"},
    "no_uncertainty_objective": {"optimization.lambda_uncertainty": 0.0},
    "simplified_chronological_transformer": {
        "model.encoder_layers": 2,
        "ablation.remove_feature_graph": True,
        "ablation.remove_funnel_biases": True,
    },
}


def assign(config: dict, dotted_key: str, value) -> None:
    keys = dotted_key.split(".")
    target = config
    for key in keys[:-1]:
        target = target.setdefault(key, {})
    target[keys[-1]] = value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--variant", choices=sorted(ABLATIONS))
    args = parser.parse_args()
    base = load_config(ROOT / args.config)
    variants = [args.variant] if args.variant else list(ABLATIONS)
    for variant in variants:
        config = copy.deepcopy(base)
        for key, value in ABLATIONS[variant].items():
            assign(config, key, value)
        output_root = ROOT / config["paths"]["output_root"] / "ablations" / variant
        results = [run_fold(config, fold, output_root) for fold in range(1, 6)]
        path = output_root / "results" / "cv_folds.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as handle:
            json.dump(results, handle, indent=2)
        relative_output = output_root.relative_to(ROOT).as_posix()
        config["paths"]["output_root"] = relative_output
        effective_config = output_root / "effective_config.yaml"
        save_config(config, effective_config)
        relative_config = effective_config.relative_to(ROOT).as_posix()
        subprocess.run([sys.executable, "scripts/train_final.py", "--config", relative_config], cwd=ROOT, check=True)
        subprocess.run([sys.executable, "scripts/external_validate.py", "--config", relative_config], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
