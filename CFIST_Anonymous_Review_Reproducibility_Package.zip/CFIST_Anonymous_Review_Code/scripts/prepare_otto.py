from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import orjson

from _bootstrap import ROOT
from cfist.cohort import construct_example
from cfist.config import load_config
from cfist.folds import assign_blocks, equal_duration_boundaries
from cfist.schema import normalize_events
from cfist.storage import ShardedSessionWriter


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def iter_jsonl(path: Path):
    with path.open("rb") as handle:
        for line_number, line in enumerate(handle, start=1):
            if line.strip():
                try:
                    yield orjson.loads(line)
                except orjson.JSONDecodeError as exc:
                    raise ValueError(f"Invalid JSON at line {line_number}") from exc


def timestamp_extent(path: Path) -> tuple[int, int]:
    lower = None
    upper = None
    for session in iter_jsonl(path):
        events = session.get("events", [])
        if not events:
            continue
        start = min(int(event["ts"]) // 1000 for event in events)
        end = max(int(event["ts"]) // 1000 for event in events)
        lower = start if lower is None else min(lower, start)
        upper = end if upper is None else max(upper, end)
    if lower is None or upper is None:
        raise ValueError("No timestamped OTTO session was found")
    return lower, upper


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    args = parser.parse_args()
    config = load_config(ROOT / args.config)
    raw_path = ROOT / config["paths"]["otto_raw"]
    output_dir = ROOT / config["paths"]["otto_processed"]
    if not raw_path.exists():
        raise FileNotFoundError(f"Missing {raw_path}; run download_data.py first")

    lower, upper = timestamp_extent(raw_path)
    boundaries = equal_duration_boundaries(
        timestamps=[lower, upper], n_blocks=int(config["data"]["otto_blocks"])
    )
    writer = ShardedSessionWriter(output_dir, int(config["data"]["parquet_rows_per_shard"]))
    counts = Counter()
    positives = Counter()
    for session in iter_jsonl(raw_path):
        counts["raw_sessions"] += 1
        normalized = normalize_events("otto", session.get("events", []))
        example, reason = construct_example(
            source="otto",
            entity_id=str(session["session"]),
            group_id=str(session["session"]),
            events=normalized,
            observation_ratio=float(config["data"]["observation_ratio"]),
            max_prefix_length=int(config["data"]["max_prefix_length"]),
        )
        counts[reason] += 1
        if example is None:
            continue
        example.block = int(assign_blocks([example.end_timestamp], boundaries)[0])
        positives[example.block] += example.label
        counts[f"block_{example.block}"] += 1
        writer.append(example)
    manifest = writer.close()
    audit = {
        "source": "otto",
        "raw_sha256": sha256(raw_path),
        "timestamp_min": lower,
        "timestamp_max": upper,
        "boundaries": [block.__dict__ for block in boundaries],
        "counts": dict(counts),
        "positives_by_block": {str(key): value for key, value in positives.items()},
        "storage": manifest,
    }
    with (output_dir / "cohort_audit.json").open("w", encoding="utf-8") as handle:
        json.dump(audit, handle, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()
