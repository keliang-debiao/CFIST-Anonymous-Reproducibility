from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from statistics import mean, stdev

import pandas as pd

from _bootstrap import ROOT


def locate(root: Path, name: str) -> Path:
    hits = list(root.rglob(name))
    if len(hits) != 1:
        raise AssertionError(f"Expected one {name} under {root}; found {len(hits)}")
    return hits[0]


def rounded(values: list[float]) -> tuple[float, float]:
    return round(mean(values), 3), round(stdev(values), 3)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--records", default="records")
    parser.add_argument("--output", default="outputs/integrity_report.json")
    args = parser.parse_args()
    records = ROOT / args.records
    checks: dict[str, object] = {}

    folds = pd.read_csv(locate(records, "cv_folds.csv"))
    assert folds["fold"].tolist() == [1, 2, 3, 4, 5]
    assert int(folds["eligible_sessions"].sum()) == 7_090_394
    targets = {"positive_prevalence": (.108, .004), "auprc": (.487, .009), "auroc": (.879, .006), "brier": (.068, .002), "ece": (.016, .002)}
    for column, expected in targets.items():
        actual = rounded(folds[column].astype(float).tolist())
        assert actual == expected, (column, actual, expected)
        checks[column] = {"mean": actual[0], "sample_sd": actual[1]}
        if column != "positive_prevalence":
            assert (folds[f"{column}_ci_low"] <= folds[column]).all()
            assert (folds[column] <= folds[f"{column}_ci_high"]).all()

    baselines = pd.read_csv(locate(records, "baseline_results.csv"))
    cfist = baselines.loc[baselines.model == "CFIST"].iloc[0]
    assert float(cfist.auprc_mean) == .487
    assert baselines.loc[baselines.model != "CFIST", "auprc_mean"].max() == .472
    assert baselines.brier_mean.min() == .067
    assert baselines.ece_mean.min() == .014

    external = pd.read_csv(locate(records, "external_validation.csv"))
    primary = external.loc[external.evaluation_set.str.contains("30 minutes")].iloc[0]
    assert int(primary.sessions) == 372_846
    assert float(primary.auprc) == .251
    assert float(primary.auprc_ci_low) == .247 and float(primary.auprc_ci_high) == .255
    assert external.iloc[0].auprc > primary.auprc

    ablations = pd.read_csv(locate(records, "ablations.csv"))
    changed = ablations.loc[ablations.variant != "Full CFIST"]
    assert (changed.paired_change < 0).all()
    assert ((changed.change_ci_low <= changed.paired_change) & (changed.paired_change <= changed.change_ci_high)).all()
    assert changed.loc[changed.variant == "Without relational tokenization", "external_auprc"].iloc[0] == .218

    calibration = pd.read_csv(locate(records, "calibration_selective.csv"))
    before = calibration.loc[calibration.condition == "CFIST before temperature scaling"].iloc[0]
    after = calibration.loc[calibration.condition == "CFIST after frozen temperature scaling"].iloc[0]
    assert before.ece - after.ece == .012
    assert after.selective_brier_80 < after.brier_100
    bins = pd.read_csv(locate(records, "calibration_bins.csv"))
    before_ece = float((bins.sample_weight * (bins.mean_probability_before - bins.observed_rate_before).abs()).sum())
    after_ece = float((bins.sample_weight * (bins.mean_probability_after - bins.observed_rate_after).abs()).sum())
    assert round(before_ece, 3) == .028 and round(after_ece, 3) == .016

    robustness = pd.read_csv(locate(records, "robustness.csv"))
    deletion = robustness.loc[robustness.condition == "Random event deletion"].copy()
    assert deletion.cfist_auprc.is_monotonic_decreasing
    assert deletion.cfist_brier.is_monotonic_increasing

    attribution = pd.read_csv(locate(records, "interpretability.csv"))
    attribution = attribution.loc[attribution.diagnostic == "Normalized absolute attribution"]
    assert round(float(attribution.estimate.sum()), 3) == 1.000

    tests = pd.read_csv(locate(records, "statistical_tests.csv"))
    assert ((tests.ci_low <= tests.estimate) & (tests.estimate <= tests.ci_high)).all()

    hashes = {}
    for path in sorted(records.rglob("*")):
        if path.is_file():
            hashes[path.relative_to(ROOT).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    checks.update({"eligible_oof_sessions": 7_090_394, "files_verified": len(hashes), "status": "passed", "sha256": hashes})
    output = ROOT / args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(checks, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", "files_verified": len(hashes), "output": str(output.relative_to(ROOT))}, indent=2))


if __name__ == "__main__":
    main()
