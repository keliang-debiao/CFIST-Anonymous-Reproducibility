from __future__ import annotations

import argparse
import subprocess
from pathlib import Path

from _bootstrap import ROOT
from cfist.config import load_config


def download(dataset: str, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    command = ["kaggle", "datasets", "download", "-d", dataset, "-p", str(destination), "--unzip"]
    subprocess.run(command, check=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    args = parser.parse_args()
    config = load_config(ROOT / args.config)
    data_root = ROOT / config["paths"]["data_root"] / "raw"
    download("otto/recsys-dataset", data_root / "otto")
    download("retailrocket/ecommerce-dataset", data_root / "retailrocket")


if __name__ == "__main__":
    main()
