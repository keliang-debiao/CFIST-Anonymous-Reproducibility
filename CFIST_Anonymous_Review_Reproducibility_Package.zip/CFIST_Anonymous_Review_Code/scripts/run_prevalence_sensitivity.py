from __future__ import annotations

import argparse
import json

import numpy as np
import pandas as pd

from _bootstrap import ROOT
from cfist.config import load_config
from cfist.metrics import binary_metrics


def resample_to_prevalence(frame: pd.DataFrame, prevalence: float, seed: int) -> pd.DataFrame:
    positive = frame[frame.label == 1]
    negative = frame[frame.label == 0]
    desired_negative = int(round(len(positive) * (1 - prevalence) / prevalence))
    rng = np.random.default_rng(seed)
    replace = desired_negative > len(negative)
    selected = rng.choice(negative.index.to_numpy(), size=desired_negative, replace=replace)
    return pd.concat([positive, negative.loc[selected]], ignore_index=True).sample(frac=1, random_state=seed)


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluation-only prevalence sensitivity without model refitting.")
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--prevalence", nargs="*", type=float, default=[.05, .15])
    args = parser.parse_args()
    config = load_config(ROOT / args.config)
    output = ROOT / config["paths"]["output_root"]
    frame = pd.concat([pd.read_parquet(output / "predictions" / f"fold_{fold}_outer.parquet") for fold in range(1, 6)], ignore_index=True)
    rows = []
    for index, prevalence in enumerate(args.prevalence):
        subset = resample_to_prevalence(frame, prevalence, int(config["evaluation"]["bootstrap_seed"]) + index)
        row = binary_metrics(subset.label, subset.probability_calibrated, int(config["evaluation"]["ece_bins"]))
        row.update({"requested_prevalence": prevalence, "sampling_with_replacement": len(subset[subset.label == 0]) > len(frame[frame.label == 0])})
        rows.append(row)
    path = output / "results" / "prevalence_sensitivity.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
