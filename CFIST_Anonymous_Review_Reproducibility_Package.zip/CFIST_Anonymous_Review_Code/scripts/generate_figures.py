from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from _bootstrap import ROOT


plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "figure.dpi": 160})


def locate(root: Path, name: str) -> Path:
    matches = list(root.rglob(name))
    if len(matches) != 1:
        raise FileNotFoundError(f"Expected one {name} under {root}; found {len(matches)}")
    return matches[0]


def errorbars(axis, x, frame, column, label, color):
    y = frame[column].to_numpy(float)
    low = frame[f"{column}_ci_low"].to_numpy(float)
    high = frame[f"{column}_ci_high"].to_numpy(float)
    axis.errorbar(x, y, yerr=np.vstack([y - low, high - y]), marker="o", capsize=3, color=color, label=label)


def save(fig, output: Path, name: str) -> None:
    fig.tight_layout()
    fig.savefig(output / f"{name}.png", dpi=300, bbox_inches="tight")
    fig.savefig(output / f"{name}.pdf", bbox_inches="tight")
    plt.close(fig)


def figure_3(records, output):
    frame = pd.read_csv(locate(records, "cv_folds.csv"))
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.1))
    for ax, metric, color in zip(axes, ["auprc", "auroc", "brier"], ["#2455A4", "#238B45", "#A63603"]):
        errorbars(ax, frame.fold, frame, metric, metric.upper(), color)
        ax.set(xlabel="Rolling temporal fold", ylabel=metric.upper(), xticks=frame.fold)
        ax.grid(alpha=.2)
    save(fig, output, "figure_3_cross_validation")


def figure_4(records, output):
    frame = pd.read_csv(locate(records, "baseline_results.csv"))
    selected = frame[frame.model.isin(["LightGBM", "FT-Transformer", "TabICLv2", "TRON-backbone", "PTE-GT-backbone", "CFIST"])]
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 3.7))
    x = np.arange(len(selected))
    axes[0].bar(x, selected.auprc_mean, yerr=selected.auprc_sd, capsize=3, color="#4472C4")
    axes[1].bar(x, selected.brier_mean, yerr=selected.brier_sd, capsize=3, color="#ED7D31")
    for ax, label in zip(axes, ["AUPRC", "Brier score"]):
        ax.set_xticks(x, selected.model, rotation=35, ha="right")
        ax.set_ylabel(label)
        ax.grid(axis="y", alpha=.2)
    save(fig, output, "figure_4_baselines")


def figure_5(records, output):
    frame = pd.read_csv(locate(records, "external_validation.csv"))
    labels = ["OTTO OOF", "RR 30 min", "RR 15 min", "RR 60 min"]
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.2))
    for ax, metric, color in zip(axes, ["auprc", "brier", "ece"], ["#2455A4", "#A63603", "#756BB1"]):
        y = frame[metric].to_numpy(float)
        lo, hi = frame[f"{metric}_ci_low"].to_numpy(float), frame[f"{metric}_ci_high"].to_numpy(float)
        ax.errorbar(np.arange(4), y, yerr=np.vstack([y-lo, hi-y]), fmt="o", capsize=3, color=color)
        ax.set_xticks(np.arange(4), labels, rotation=30, ha="right")
        ax.set_ylabel(metric.upper())
        ax.grid(axis="y", alpha=.2)
    save(fig, output, "figure_5_external_validation")


def figure_6(records, output):
    frame = pd.read_csv(locate(records, "ablations.csv"))
    frame = frame[frame.variant != "Full CFIST"].iloc[::-1]
    fig, ax = plt.subplots(figsize=(7.8, 5.5))
    x = frame.paired_change.to_numpy(float)
    ax.errorbar(x, np.arange(len(frame)), xerr=np.vstack([x-frame.change_ci_low, frame.change_ci_high-x]), fmt="o", capsize=3, color="#2455A4")
    ax.axvline(0, color="black", linewidth=.8)
    ax.set_yticks(np.arange(len(frame)), frame.variant)
    ax.set_xlabel("Paired AUPRC change from full CFIST")
    ax.grid(axis="x", alpha=.2)
    save(fig, output, "figure_6_ablation")


def figure_7(records, output):
    calibration = pd.read_csv(locate(records, "calibration_selective.csv"))
    bins = pd.read_csv(locate(records, "calibration_bins.csv"))
    robustness = pd.read_csv(locate(records, "robustness.csv"))
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.4))
    axes[0].plot([0, 1], [0, 1], "--", color="gray")
    axes[0].plot(bins.mean_probability_before, bins.observed_rate_before, "o-", label="Before scaling")
    axes[0].plot(bins.mean_probability_after, bins.observed_rate_after, "o-", label="After scaling")
    axes[0].set(xlabel="Mean predicted probability", ylabel="Observed frequency")
    axes[0].legend(frameon=False, fontsize=8)
    after_row = calibration.loc[calibration.condition == "CFIST after frozen temperature scaling"].iloc[0]
    ext_row = calibration.loc[calibration.condition == "CFIST frozen zero-shot"].iloc[0]
    x = np.arange(2)
    axes[1].bar(x-.18, [after_row.brier_100, ext_row.brier_100], .36, label="100%")
    axes[1].bar(x+.18, [after_row.selective_brier_80, ext_row.selective_brier_80], .36, label="80%")
    axes[1].set_xticks(x, ["OTTO", "Retailrocket"])
    axes[1].set_ylabel("Selective Brier risk")
    axes[1].legend(frameon=False)
    subset = robustness.iloc[:6]
    q = np.arange(len(subset))
    axes[2].plot(q, subset.cfist_auprc, "o-", label="CFIST")
    axes[2].plot(q, subset.pte_gt_auprc, "o-", label="PTE-GT")
    axes[2].set_xticks(q, ["Base", "Del10", "Del30", "Del50", "Time", "Stage"], rotation=35)
    axes[2].set_ylabel("AUPRC")
    axes[2].legend(frameon=False)
    save(fig, output, "figure_7_calibration_robustness")


def figure_8(records, output):
    tests = pd.read_csv(locate(records, "statistical_tests.csv")).iloc[:5].iloc[::-1]
    attribution = pd.read_csv(locate(records, "interpretability.csv"))
    attribution = attribution[attribution.diagnostic == "Normalized absolute attribution"]
    efficiency = pd.read_csv(locate(records, "efficiency.csv")).dropna(subset=["inference_ms_per_1000_median"])
    baselines = pd.read_csv(locate(records, "baseline_results.csv"))[["model", "auprc_mean"]]
    efficiency = efficiency.merge(baselines, on="model", how="left")
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.8))
    x = tests.estimate.to_numpy(float)
    axes[0].errorbar(x, np.arange(len(tests)), xerr=np.vstack([x-tests.ci_low, tests.ci_high-x]), fmt="o", capsize=3)
    axes[0].axvline(0, color="black", linewidth=.8)
    axes[0].set_yticks(np.arange(len(tests)), tests.comparator_or_analysis)
    axes[0].set_xlabel("Paired AUPRC difference")
    axes[1].barh(np.arange(len(attribution)), attribution.estimate)
    axes[1].set_yticks(np.arange(len(attribution)), attribution.feature_or_prefix_stratum)
    axes[1].set_xlabel("Normalized attribution")
    axes[2].scatter(efficiency.inference_ms_per_1000_median, efficiency.auprc_mean)
    for _, row in efficiency.iterrows():
        offset = (-28, 3) if row.model == "CFIST" else (3, 2)
        axes[2].annotate(row.model, (row.inference_ms_per_1000_median, row.auprc_mean), xytext=offset, textcoords="offset points", fontsize=7)
    axes[2].set(xlabel="Inference time per 1,000 sessions (ms)", ylabel="AUPRC")
    axes[2].margins(x=.08, y=.08)
    save(fig, output, "figure_8_statistics_interpretability")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--records", default="records")
    parser.add_argument("--output", default="outputs/figures")
    args = parser.parse_args()
    records, output = ROOT / args.records, ROOT / args.output
    output.mkdir(parents=True, exist_ok=True)
    for function in (figure_3, figure_4, figure_5, figure_6, figure_7, figure_8):
        function(records, output)
    print(f"Generated Figures 3-8 in {output.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
