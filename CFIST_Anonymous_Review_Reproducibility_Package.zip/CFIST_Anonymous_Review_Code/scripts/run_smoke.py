from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from _bootstrap import ROOT
from cfist.cohort import adjacent_prefix, construct_example
from cfist.config import load_config, set_global_seed
from cfist.constants import GRAPH_FEATURE_NAMES, RELATION_FEATURE_NAMES
from cfist.folds import assert_no_group_overlap, assign_blocks, equal_duration_boundaries, rolling_outer_fold
from cfist.schema import RawEvent


def build_events(index: int) -> list[RawEvent]:
    start = 1_700_000_000 + index * 300
    order = index % 4 == 0
    stages = ["click", "click", "cart", "click", "click", "order" if order else "click"]
    return [RawEvent(timestamp=start + position * 12, item_id=str((index + position) % 7), stage=stage) for position, stage in enumerate(stages)]


def make_batch(examples, device):
    import torch

    length = max(len(row.stage_ids) for row in examples)
    batch = len(examples)
    stage = torch.zeros((batch, length), dtype=torch.long, device=device)
    item = torch.full((batch, length), -1, dtype=torch.long, device=device)
    gap = torch.zeros((batch, length), dtype=torch.long, device=device)
    relations = torch.zeros((batch, length, len(RELATION_FEATURE_NAMES)), dtype=torch.float32, device=device)
    mask = torch.zeros((batch, length), dtype=torch.bool, device=device)
    graph = torch.zeros((batch, len(GRAPH_FEATURE_NAMES)), dtype=torch.float32, device=device)
    for index, row in enumerate(examples):
        size = len(row.stage_ids)
        stage[index, :size] = torch.as_tensor(row.stage_ids)
        item[index, :size] = torch.as_tensor(row.item_codes)
        raw_gaps = np.log1p(np.asarray(row.gap_seconds, dtype=float))
        gap[index, :size] = torch.as_tensor(np.minimum(15, np.floor(raw_gaps)).astype(np.int64))
        relations[index, :size] = torch.as_tensor(row.relations)
        graph[index] = torch.as_tensor(row.graph_features)
        mask[index, :size] = True
    return {
        "stage_ids": stage, "item_codes": item, "gap_bins": gap, "relations": relations,
        "attention_mask": mask, "graph_features": graph,
        "prefix_length": torch.as_tensor([row.prefix_length for row in examples], dtype=torch.float32, device=device),
        "label": torch.as_tensor([row.label for row in examples], dtype=torch.float32, device=device),
        "next_stage": torch.as_tensor([row.next_stage for row in examples], dtype=torch.long, device=device),
        "environment": torch.as_tensor([index % 3 for index in range(batch)], dtype=torch.long, device=device),
    }


def main() -> None:
    import torch

    from cfist.losses import GroupDRO, complete_objective
    from cfist.model import build_model

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/smoke.yaml")
    args = parser.parse_args()
    config = load_config(ROOT / args.config)
    seed = int(config["seeds"][0])
    set_global_seed(seed)
    examples = []
    for index in range(48):
        example, reason = construct_example(source="integrity", entity_id=f"s{index}", group_id=f"g{index}", events=build_events(index), max_prefix_length=12)
        assert reason == "eligible" and example is not None
        examples.append(example)
    boundaries = equal_duration_boundaries(np.asarray([row.end_timestamp for row in examples]), 6)
    blocks = assign_blocks(np.asarray([row.end_timestamp for row in examples]), boundaries)
    train, validation = rolling_outer_fold(blocks, 5)
    assert_no_group_overlap(np.asarray([row.group_id for row in examples]), train, validation)

    device = torch.device("cpu")
    long_batch = make_batch(examples[:16], device)
    shorter = [adjacent_prefix(row) or row for row in examples[:16]]
    short_batch = make_batch(shorter, device)
    model = build_model(config).to(device)
    output = model(long_batch)
    short_output = model(short_batch)
    group_dro = GroupDRO(3, minimum_samples=2)
    loss, diagnostics = complete_objective(
        output=output, short_output=short_output, batch=long_batch,
        adjacent_valid=torch.ones(16, dtype=torch.bool), group_dro=group_dro,
        positive_weight=3.0, negative_weight=1.0,
        lambda_stage=.10, lambda_prefix=.05, lambda_uncertainty=.10,
    )
    loss.backward()
    assert torch.isfinite(loss)
    assert output.probability.shape == (16,)
    assert torch.all((output.probability >= 0) & (output.probability <= 1))
    report = {
        "status": "passed", "examples": len(examples), "training_examples": int(len(train)),
        "validation_examples": int(len(validation)), "parameters": sum(parameter.numel() for parameter in model.parameters()),
        **{name: round(value, 6) for name, value in diagnostics.items() if name.startswith("loss_")},
    }
    output_path = ROOT / config["paths"]["output_root"] / "smoke_report.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
