from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from _bootstrap import ROOT


def run(*arguments: str) -> None:
    command = [sys.executable, *arguments]
    print("+", " ".join(command), flush=True)
    subprocess.run(command, cwd=ROOT, check=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--skip-download", action="store_true")
    args = parser.parse_args()
    if not args.skip_download:
        run("scripts/download_data.py", "--config", args.config)
    run("scripts/prepare_otto.py", "--config", args.config)
    run("scripts/prepare_retailrocket.py", "--config", args.config)
    run("scripts/run_selection.py", "--config", args.config)
    run("scripts/train_cv.py", "--config", args.config)
    run("scripts/train_final.py", "--config", args.config)
    for model in ["Logistic regression", "Random forest", "XGBoost", "LightGBM", "MLP", "TabNet", "FT-Transformer", "GRU4Rec", "SASRec", "SR-GNN", "TRON-backbone", "PTE-GT-backbone"]:
        for fold in range(1, 6):
            run("scripts/run_baselines.py", "--config", args.config, "--model", model, "--fold", str(fold))
    run("scripts/run_ablations.py", "--config", args.config)
    run("scripts/external_validate.py", "--config", args.config)
    for minutes in (15, 60):
        run("scripts/prepare_retailrocket.py", "--config", args.config, "--inactivity-minutes", str(minutes))
        run("scripts/external_validate.py", "--config", args.config, "--inactivity-minutes", str(minutes))
    for condition, severity in [("event_deletion", 0.10), ("event_deletion", 0.30), ("event_deletion", 0.50), ("timestamp_noise", 0.10), ("stage_noise", 0.10)]:
        for model in ("CFIST", "PTE-GT-backbone"):
            for fold in range(1, 6):
                run("scripts/run_robustness.py", "--config", args.config, "--model", model, "--fold", str(fold), "--condition", condition, "--severity", str(severity))
    run("scripts/run_statistics.py", "--config", args.config)
    run("scripts/run_low_data.py", "--config", args.config)
    run("scripts/run_prevalence_sensitivity.py", "--config", args.config)
    run("scripts/verify_empirical_outputs.py", "--config", args.config, "--targets", "records")


if __name__ == "__main__":
    main()
