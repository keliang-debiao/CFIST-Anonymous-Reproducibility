from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np

from _bootstrap import ROOT
from cfist.config import load_config, set_global_seed
from cfist.metrics import binary_metrics
from cfist.model import build_model
from cfist.preprocessing import fit_preprocessor_from_dataset
from cfist.selection import candidate_configurations
from cfist.training import fit_network, predict
from train_cv import collect_timestamps, make_loader


def main() -> None:
    import torch

    parser = argparse.ArgumentParser(description="Nested chronological configuration selection inside each outer historical interval.")
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--fold", type=int, choices=range(1, 6))
    args = parser.parse_args()
    config = load_config(ROOT / args.config)
    dataset_dir = ROOT / config["paths"]["otto_processed"]
    output_root = ROOT / config["paths"]["output_root"]
    folds = [args.fold] if args.fold else list(range(1, 6))
    requested = config["project"].get("device", "auto")
    device = torch.device("cuda" if requested == "auto" and torch.cuda.is_available() else ("cpu" if requested == "auto" else requested))

    for fold in folds:
        historical = set(range(fold))
        timestamps = np.sort(collect_timestamps(dataset_dir, historical))
        split_count = int(config["selection"]["inner_temporal_splits"])
        validation_end_fraction = np.linspace(.70, 1.00, split_count)
        training_end_fraction = validation_end_fraction - .15
        intervals = [
            (
                int(np.quantile(timestamps, train_fraction, method="lower")),
                int(np.quantile(timestamps, validation_fraction, method="lower")),
            )
            for train_fraction, validation_fraction in zip(training_end_fraction, validation_end_fraction)
        ]
        search_seed = int(config["seeds"][0]) + fold
        candidates = candidate_configurations(config, search_seed)
        records = []
        best_score, best = -np.inf, None
        for candidate in candidates:
            trial = int(candidate["selection_record"]["trial"])
            split_scores = []
            for split_index, (training_end, validation_end) in enumerate(intervals, start=1):
                preprocessor = fit_preprocessor_from_dataset(
                    dataset_dir, include_blocks=historical, fold=fold,
                    gap_bins=int(config["data"]["gap_bins"]), end_timestamp_at_most=training_end,
                )
                seed = search_seed + split_index
                set_global_seed(seed, bool(config["project"]["deterministic"]))
                training_loader = make_loader(candidate, dataset_dir, historical, preprocessor, seed, shuffle=True, at_most=training_end)
                development_loader = make_loader(candidate, dataset_dir, historical, preprocessor, seed, shuffle=False, at_most=validation_end, after=training_end)
                model = build_model(candidate)
                model, _ = fit_network(
                    model=model, training_loader=training_loader, development_loader=development_loader,
                    config=candidate, preprocessor=preprocessor, fold=fold, seed=seed,
                    output_dir=output_root / "selection" / f"fold_{fold}" / f"trial_{trial}" / f"split_{split_index}",
                )
                result = predict(model, development_loader, device)
                split_scores.append(binary_metrics(result["label"], result["probability"])["auprc"])
            mean_score = float(np.mean(split_scores))
            records.append({
                "trial": trial, "mean_auprc": mean_score, "split_auprc": split_scores,
                "optimization": candidate["optimization"], "intervals": intervals,
            })
            if mean_score > best_score:
                best_score, best = mean_score, copy.deepcopy(candidate)
        if best is None:
            raise RuntimeError(f"No configuration completed for outer fold {fold}")
        selection_dir = output_root / "selection"
        selection_dir.mkdir(parents=True, exist_ok=True)
        (selection_dir / f"fold_{fold}_trials.json").write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
        (selection_dir / f"fold_{fold}_selected.json").write_text(json.dumps({
            "outer_fold": fold, "mean_inner_auprc": best_score,
            "optimization": best["optimization"], "selection_seed": search_seed,
        }, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
