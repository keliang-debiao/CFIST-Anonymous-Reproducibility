from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import pandas as pd

from _bootstrap import ROOT
from cfist.cohort import construct_example
from cfist.config import load_config
from cfist.schema import normalize_events
from cfist.sessionization import sessionize_visitor_events
from cfist.storage import ShardedSessionWriter


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--inactivity-minutes", type=int)
    args = parser.parse_args()
    config = load_config(ROOT / args.config)
    raw_path = ROOT / config["paths"]["retailrocket_raw"]
    inactivity = args.inactivity_minutes or int(config["data"]["retailrocket_inactivity_minutes"])
    base_output = ROOT / config["paths"]["retailrocket_processed"]
    output_dir = base_output / f"{inactivity}min"
    if not raw_path.exists():
        raise FileNotFoundError(f"Missing {raw_path}; run download_data.py first")

    frame = pd.read_csv(
        raw_path,
        usecols=["timestamp", "visitorid", "event", "itemid", "transactionid"],
        dtype={"visitorid": "string", "event": "category", "itemid": "string"},
    )
    frame.sort_values(["visitorid", "timestamp", "itemid", "event"], inplace=True, kind="stable")
    writer = ShardedSessionWriter(output_dir, int(config["data"]["parquet_rows_per_shard"]))
    counts = Counter(raw_events=len(frame), raw_visitors=frame["visitorid"].nunique())
    positives = 0
    for visitor_id, group in frame.groupby("visitorid", sort=False, observed=True):
        events = normalize_events("retailrocket", group.to_dict("records"))
        for session_id, session_events in sessionize_visitor_events(str(visitor_id), events, inactivity):
            counts["constructed_sessions"] += 1
            example, reason = construct_example(
                source="retailrocket",
                entity_id=session_id,
                group_id=str(visitor_id),
                events=session_events,
                observation_ratio=float(config["data"]["observation_ratio"]),
                max_prefix_length=int(config["data"]["max_prefix_length"]),
            )
            counts[reason] += 1
            if example is None:
                continue
            positives += example.label
            writer.append(example)
    manifest = writer.close()
    eligible = counts["eligible"]
    audit = {
        "source": "retailrocket",
        "raw_sha256": sha256(raw_path),
        "inactivity_minutes": inactivity,
        "counts": dict(counts),
        "positive_sessions": positives,
        "positive_rate": positives / eligible if eligible else None,
        "storage": manifest,
    }
    with (output_dir / "cohort_audit.json").open("w", encoding="utf-8") as handle:
        json.dump(audit, handle, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()
