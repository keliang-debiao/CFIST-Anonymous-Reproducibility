from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from _bootstrap import ROOT
from cfist.baseline_training import fit_binary_network, predict_binary_network
from cfist.baselines import build_neural_baseline
from cfist.calibration import TemperatureScaler
from cfist.config import load_config, set_global_seed
from cfist.metrics import binary_metrics
from cfist.preprocessing import fit_preprocessor_from_dataset
from cfist.storage import iter_session_rows
from train_cv import collect_timestamps, make_loader


BUILT_IN_NEURAL = ["MLP", "FT-Transformer", "GRU4Rec", "SASRec", "SR-GNN", "TRON-backbone", "PTE-GT-backbone"]


def traditional_estimator(name: str, positive_rate: float, seed: int):
    if name == "Logistic regression":
        from sklearn.linear_model import LogisticRegression

        return LogisticRegression(C=1.0, class_weight="balanced", max_iter=1000, random_state=seed)
    if name == "Random forest":
        from sklearn.ensemble import RandomForestClassifier

        return RandomForestClassifier(n_estimators=600, max_depth=20, class_weight="balanced_subsample", n_jobs=-1, random_state=seed)
    if name == "XGBoost":
        from xgboost import XGBClassifier

        return XGBClassifier(n_estimators=800, max_depth=6, learning_rate=0.03, subsample=0.8, colsample_bytree=0.8, scale_pos_weight=(1 - positive_rate) / positive_rate, n_jobs=-1, random_state=seed)
    if name == "LightGBM":
        from lightgbm import LGBMClassifier

        return LGBMClassifier(n_estimators=800, num_leaves=63, learning_rate=0.03, class_weight="balanced", n_jobs=-1, random_state=seed)
    raise ValueError(name)


def load_tabular(dataset_dir: Path, blocks: set[int], preprocessor, at_most=None, after=None):
    x, y, ids = [], [], []
    for row in iter_session_rows(dataset_dir):
        if int(row["block"]) not in blocks:
            continue
        timestamp = int(row["end_timestamp"])
        if at_most is not None and timestamp > at_most:
            continue
        if after is not None and timestamp <= after:
            continue
        x.append(row["graph_features"])
        y.append(int(row["label"]))
        ids.append(str(row["entity_id"]))
    return preprocessor.transform_graph(np.asarray(x)), np.asarray(y), np.asarray(ids, dtype=object)


def main() -> None:
    import torch

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--model", default="LightGBM")
    parser.add_argument("--fold", type=int, default=5, choices=range(1, 6))
    args = parser.parse_args()
    config = load_config(ROOT / args.config)
    dataset_dir = ROOT / config["paths"]["otto_processed"]
    output_root = ROOT / config["paths"]["output_root"]
    requested = config["project"].get("device", "auto")
    device = torch.device("cuda" if requested == "auto" and torch.cuda.is_available() else ("cpu" if requested == "auto" else requested))
    historical = set(range(args.fold))
    development_cut = int(np.quantile(collect_timestamps(dataset_dir, historical), 0.90, method="lower"))
    preprocessor = fit_preprocessor_from_dataset(dataset_dir, include_blocks=historical, fold=args.fold, gap_bins=int(config["data"]["gap_bins"]), end_timestamp_at_most=development_cut)
    slug = args.model.lower().replace(" ", "_")
    artifact_dir = output_root / "results" / "baselines"
    artifact_dir.mkdir(parents=True, exist_ok=True)

    if args.model in {"Logistic regression", "Random forest", "XGBoost", "LightGBM", "TabNet"}:
        x_train, y_train, _ = load_tabular(dataset_dir, historical, preprocessor, at_most=development_cut)
        x_dev, y_dev, _ = load_tabular(dataset_dir, historical, preprocessor, after=development_cut)
        x_outer, y_outer, ids = load_tabular(dataset_dir, {args.fold}, preprocessor)
        dev_runs, outer_runs = [], []
        for raw_seed in config["seeds"]:
            seed = int(raw_seed)
            set_global_seed(seed)
            if args.model == "TabNet":
                from pytorch_tabnet.tab_model import TabNetClassifier

                estimator = TabNetClassifier(
                    n_d=32, n_a=32, n_steps=5, gamma=1.5,
                    lambda_sparse=1.0e-4, seed=seed, verbose=0,
                    device_name=device.type,
                )
                estimator.fit(
                    x_train.astype(np.float32), y_train,
                    eval_set=[(x_dev.astype(np.float32), y_dev)], eval_name=["development"],
                    eval_metric=["auc"], max_epochs=100, patience=10,
                    batch_size=8192, virtual_batch_size=1024, num_workers=0,
                    weights=1, drop_last=False,
                )
                dev_runs.append(estimator.predict_proba(x_dev.astype(np.float32))[:, 1])
                outer_runs.append(estimator.predict_proba(x_outer.astype(np.float32))[:, 1])
            else:
                estimator = traditional_estimator(args.model, float(y_train.mean()), seed)
                estimator.fit(x_train, y_train)
                dev_runs.append(estimator.predict_proba(x_dev)[:, 1])
                outer_runs.append(estimator.predict_proba(x_outer)[:, 1])
        dev_probability = np.mean(np.stack(dev_runs), axis=0)
        outer_probability = np.mean(np.stack(outer_runs), axis=0)
        scaler = TemperatureScaler().fit(
            np.log(np.clip(dev_probability, 1e-7, 1 - 1e-7) / np.clip(1 - dev_probability, 1e-7, 1)),
            y_dev,
        )
        probability = scaler.transform_probability(outer_probability)
        result = binary_metrics(y_outer, probability, int(config["evaluation"]["ece_bins"]))
        prediction_frame = pd.DataFrame({"entity_id": ids, "group_id": ids, "label": y_outer, "probability_raw": outer_probability, "probability_calibrated": probability})
    elif args.model in BUILT_IN_NEURAL:
        development_runs, outer_runs = [], []
        for raw_seed in config["seeds"]:
            seed = int(raw_seed)
            set_global_seed(seed)
            model = build_neural_baseline(args.model, config)
            training_loader = make_loader(config, dataset_dir, historical, preprocessor, seed, shuffle=True, at_most=development_cut)
            development_loader = make_loader(config, dataset_dir, historical, preprocessor, seed, shuffle=False, after=development_cut)
            outer_loader = make_loader(config, dataset_dir, {args.fold}, preprocessor, seed, shuffle=False)
            model = fit_binary_network(model, training_loader, development_loader, config, preprocessor.positive_weight, device)
            development_predictions = predict_binary_network(model, development_loader, device)
            predictions = predict_binary_network(model, outer_loader, device)
            development_runs.append(development_predictions)
            outer_runs.append(predictions)
            torch.save({"model_state": model.state_dict(), "model": args.model, "fold": args.fold, "seed": seed, "configuration": config}, artifact_dir / f"{slug}_fold_{args.fold}_seed_{seed}.pt")
        reference_ids = outer_runs[0]["entity_id"]
        if any(not np.array_equal(run["entity_id"], reference_ids) for run in outer_runs[1:]):
            raise AssertionError("Seed-specific baseline predictions are not row aligned")
        if any(not np.array_equal(run["entity_id"], development_runs[0]["entity_id"]) for run in development_runs[1:]):
            raise AssertionError("Seed-specific development predictions are not row aligned")
        dev_p = np.mean(np.stack([run["probability"] for run in development_runs]), axis=0)
        outer_probability = np.mean(np.stack([run["probability"] for run in outer_runs]), axis=0)
        scaler = TemperatureScaler().fit(
            np.log(np.clip(dev_p, 1e-7, 1 - 1e-7) / np.clip(1 - dev_p, 1e-7, 1)),
            development_runs[0]["label"],
        )
        probability = scaler.transform_probability(outer_probability)
        result = binary_metrics(outer_runs[0]["label"], probability, int(config["evaluation"]["ece_bins"]))
        prediction_frame = pd.DataFrame({
            "entity_id": outer_runs[0]["entity_id"],
            "group_id": outer_runs[0]["group_id"],
            "label": outer_runs[0]["label"],
            "probability_raw": outer_probability,
            "probability_calibrated": probability,
        })
    else:
        raise ValueError("TabICLv2 requires its official release output; import it with scripts/import_official_predictions.py")
    result.update({"model": args.model, "fold": args.fold})
    result["temperature"] = scaler.temperature
    path = artifact_dir / f"{slug}_fold_{args.fold}.json"
    with path.open("w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)
    prediction_frame.to_parquet(path.with_suffix(".parquet"), index=False, compression="zstd")


if __name__ == "__main__":
    main()
