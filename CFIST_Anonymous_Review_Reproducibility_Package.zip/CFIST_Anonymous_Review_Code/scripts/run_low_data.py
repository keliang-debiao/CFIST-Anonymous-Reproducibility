from __future__ import annotations

import argparse
import copy
import json

from _bootstrap import ROOT
from cfist.config import load_config
from train_cv import run_fold


def main() -> None:
    parser = argparse.ArgumentParser(description="Fold-internal deterministic training-fraction analysis.")
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--fractions", nargs="*", type=float, default=[.01, .05, .10, .25, .50, 1.00])
    args = parser.parse_args()
    base = load_config(ROOT / args.config)
    base_output = ROOT / base["paths"]["output_root"] / "low_data"
    for fraction in args.fractions:
        config = copy.deepcopy(base)
        config["optimization"]["training_fraction"] = float(fraction)
        config["optimization"]["training_fraction_seed"] = 424242
        name = f"fraction_{fraction:.2f}"
        output = base_output / name
        rows = [run_fold(config, fold, output) for fold in range(1, 6)]
        path = output / "results" / "cv_folds.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
