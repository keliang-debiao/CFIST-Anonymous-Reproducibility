from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, brier_score_loss

from _bootstrap import ROOT
from cfist.config import load_config
from cfist.statistics import holm_adjust, paired_cluster_bootstrap_difference


def read_oof(paths: list[Path], probability_column: str) -> pd.DataFrame:
    frames = []
    for path in paths:
        frame = pd.read_parquet(path)
        frame = frame[["entity_id", "group_id", "label", probability_column]].copy()
        frame.rename(columns={probability_column: "probability"}, inplace=True)
        frames.append(frame)
    return pd.concat(frames, ignore_index=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--comparators", nargs="*", default=["LightGBM", "FT-Transformer", "TabICLv2", "TRON-backbone", "PTE-GT-backbone"])
    args = parser.parse_args()
    config = load_config(ROOT / args.config)
    output_root = ROOT / config["paths"]["output_root"]
    cfist = read_oof(
        [output_root / "predictions" / f"fold_{fold}_outer.parquet" for fold in range(1, 6)],
        "probability_calibrated",
    )
    rows = []
    raw_p = []
    for comparator in args.comparators:
        slug = comparator.lower().replace(" ", "_")
        candidate_paths = [output_root / "results" / "baselines" / f"{slug}_fold_{fold}.parquet" for fold in range(1, 6)]
        if not all(path.exists() for path in candidate_paths):
            continue
        baseline = read_oof(candidate_paths, "probability_calibrated")
        merged = cfist.merge(baseline, on=["entity_id", "group_id", "label"], suffixes=("_cfist", "_baseline"), validate="one_to_one")
        estimate, interval, p_value, _ = paired_cluster_bootstrap_difference(
            labels=merged["label"].to_numpy(),
            predictions_a=merged["probability_cfist"].to_numpy(),
            predictions_b=merged["probability_baseline"].to_numpy(),
            clusters=merged["group_id"].to_numpy(),
            statistic=average_precision_score,
            resamples=int(config["evaluation"]["bootstrap_resamples"]),
            seed=int(config["evaluation"]["bootstrap_seed"]),
        )
        baseline_score = average_precision_score(merged["label"], merged["probability_baseline"])
        rows.append({
            "comparator": comparator,
            "estimand": "otto_oof_auprc_difference",
            "estimate": estimate,
            "ci_low": interval[0],
            "ci_high": interval[1],
            "raw_p": p_value,
            "relative_gain_percent": 100.0 * estimate / baseline_score,
        })
        raw_p.append(p_value)
    adjusted = holm_adjust(raw_p)
    for row, value in zip(rows, adjusted):
        row["holm_adjusted_p"] = value

    if any(row["comparator"] == "LightGBM" for row in rows):
        comparator = "LightGBM"
        slug = comparator.lower().replace(" ", "_")
        baseline = read_oof(
            [output_root / "results" / "baselines" / f"{slug}_fold_{fold}.parquet" for fold in range(1, 6)],
            "probability_calibrated",
        )
        merged = cfist.merge(baseline, on=["entity_id", "group_id", "label"], suffixes=("_cfist", "_baseline"), validate="one_to_one")
        estimate, interval, p_value, _ = paired_cluster_bootstrap_difference(
            labels=merged["label"].to_numpy(),
            predictions_a=merged["probability_cfist"].to_numpy(),
            predictions_b=merged["probability_baseline"].to_numpy(),
            clusters=merged["group_id"].to_numpy(),
            statistic=brier_score_loss,
            resamples=int(config["evaluation"]["bootstrap_resamples"]),
            seed=int(config["evaluation"]["bootstrap_seed"]) + 1,
        )
        rows.append({
            "comparator": comparator,
            "estimand": "otto_oof_brier_difference_positive_favors_baseline",
            "estimate": estimate,
            "ci_low": interval[0],
            "ci_high": interval[1],
            "raw_p": p_value,
            "holm_adjusted_p": min(1.0, 4.0 * p_value),
            "relative_gain_percent": 100.0 * estimate / brier_score_loss(merged["label"], merged["probability_baseline"]),
        })
    path = output_root / "results" / "statistical_tests.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False)


if __name__ == "__main__":
    main()
