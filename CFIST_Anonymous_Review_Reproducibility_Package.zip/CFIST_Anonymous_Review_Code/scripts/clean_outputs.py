from __future__ import annotations

import shutil
from pathlib import Path

from _bootstrap import ROOT


ALLOWED = [
    ROOT / "outputs" / "tables",
    ROOT / "outputs" / "figures",
    ROOT / "outputs" / "smoke",
]


def main() -> None:
    for path in ALLOWED:
        resolved = path.resolve()
        if ROOT.resolve() not in resolved.parents:
            raise RuntimeError(f"Refusing to remove path outside repository: {resolved}")
        if path.exists():
            shutil.rmtree(path)


if __name__ == "__main__":
    main()
