from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from _bootstrap import ROOT
from cfist.config import load_config, save_json, set_global_seed
from cfist.model import build_model
from cfist.posthoc import FrozenPosthocState
from cfist.preprocessing import fit_preprocessor_from_dataset
from cfist.storage import iter_session_rows
from cfist.training import fit_network, predict
from train_cv import average_predictions, make_loader


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    args = parser.parse_args()
    config = load_config(ROOT / args.config)
    output_root = ROOT / config["paths"]["output_root"]
    dataset_dir = ROOT / config["paths"]["otto_processed"]
    blocks = set(range(int(config["data"]["otto_blocks"])))
    timestamps = np.asarray(
        [int(row["end_timestamp"]) for row in iter_session_rows(dataset_dir, ["end_timestamp"])],
        dtype=np.int64,
    )
    development_cut = int(
        np.quantile(timestamps, 1.0 - float(config["data"]["development_fraction"]), method="lower")
    )
    preprocessor = fit_preprocessor_from_dataset(
        dataset_dir,
        include_blocks=blocks,
        fold=6,
        gap_bins=int(config["data"]["gap_bins"]),
        end_timestamp_at_most=development_cut,
    )
    save_json(preprocessor.to_dict(), output_root / "preprocessing" / "final.json")
    development_runs = []
    fitting_runs = []
    for seed in config["seeds"]:
        seed = int(seed)
        set_global_seed(seed, bool(config["project"]["deterministic"]))
        model = build_model(config)
        training_loader = make_loader(config, dataset_dir, blocks, preprocessor, seed, shuffle=True, at_most=development_cut)
        development_loader = make_loader(config, dataset_dir, blocks, preprocessor, seed, shuffle=False, after=development_cut)
        model, training_record = fit_network(
            model=model,
            training_loader=training_loader,
            development_loader=development_loader,
            config=config,
            preprocessor=preprocessor,
            fold=6,
            seed=seed,
            output_dir=output_root / "checkpoints",
        )
        import torch

        requested = config["project"].get("device", "auto")
        device = torch.device("cuda" if requested == "auto" and torch.cuda.is_available() else ("cpu" if requested == "auto" else requested))
        fitting_runs.append(predict(model, make_loader(config, dataset_dir, blocks, preprocessor, seed, shuffle=False, at_most=development_cut), device))
        development_runs.append(predict(model, make_loader(config, dataset_dir, blocks, preprocessor, seed, shuffle=False, after=development_cut), device))
    fitting = average_predictions(fitting_runs)
    development = average_predictions(development_runs)
    state = FrozenPosthocState.fit(
        development,
        prototype_predictions=fitting,
        coverage_levels=tuple(config["evaluation"]["coverage_levels"]),
        uncertainty_mode=config.get("posthoc_mode", "dual"),
    )
    final_state_path = output_root / "calibration" / "final.json"
    final_state_path.parent.mkdir(parents=True, exist_ok=True)
    with final_state_path.open("w", encoding="utf-8") as handle:
        json.dump(state.to_dict(), handle, indent=2)
    save_json(
        {"development_cut": development_cut, "fitting_sessions": len(fitting["label"]), "development_sessions": len(development["label"])},
        output_root / "calibration" / "final_partition.json",
    )


if __name__ == "__main__":
    main()
