from __future__ import annotations

import argparse
import json
from pathlib import Path
from statistics import mean, stdev

import pandas as pd

from _bootstrap import ROOT
from cfist.config import load_config


def difference(actual: float, target: float) -> float:
    return float(actual) - float(target)


def main() -> None:
    parser = argparse.ArgumentParser(description="Compare a fresh execution with the manuscript-aligned target layer.")
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--targets", default="records")
    parser.add_argument("--primary-tolerance", type=float, default=.020)
    args = parser.parse_args()
    config = load_config(ROOT / args.config)
    output = ROOT / config["paths"]["output_root"]
    targets = ROOT / args.targets
    report: dict[str, object] = {"status": "passed", "checks": {}, "unavailable_optional_rows": []}

    cv_path = output / "results" / "cv_folds.json"
    if not cv_path.exists():
        raise FileNotFoundError(cv_path)
    folds = json.loads(cv_path.read_text(encoding="utf-8"))
    target_folds = pd.read_csv(targets / "results" / "cv_folds.csv")
    for metric in ("auprc", "auroc", "brier", "ece"):
        values = [float(row[metric]) for row in folds]
        actual_mean = mean(values)
        actual_sd = stdev(values)
        target_mean = float(target_folds[metric].mean())
        delta = difference(actual_mean, target_mean)
        report["checks"][f"cv_{metric}"] = {"mean": actual_mean, "sample_sd": actual_sd, "target": target_mean, "difference": delta}
        if abs(delta) > args.primary_tolerance:
            report["status"] = "review_required"

    target_baselines = pd.read_csv(targets / "results" / "baseline_results.csv")
    for _, target in target_baselines.iterrows():
        if target.model == "CFIST":
            continue
        slug = str(target.model).lower().replace(" ", "_")
        files = [output / "results" / "baselines" / f"{slug}_fold_{fold}.json" for fold in range(1, 6)]
        if not all(path.exists() for path in files):
            report["unavailable_optional_rows"].append(str(target.model))
            continue
        values = [json.loads(path.read_text(encoding="utf-8"))["auprc"] for path in files]
        actual = mean(values)
        delta = difference(actual, target.auprc_mean)
        report["checks"][f"baseline_{slug}"] = {"auprc": actual, "target": float(target.auprc_mean), "difference": delta}
        if abs(delta) > args.primary_tolerance:
            report["status"] = "review_required"

    target_external = pd.read_csv(targets / "results" / "external_validation.csv")
    for minutes in (30, 15, 60):
        path = output / "results" / f"external_{minutes}min.json"
        if not path.exists():
            report["unavailable_optional_rows"].append(f"Retailrocket {minutes} minutes")
            continue
        actual_row = json.loads(path.read_text(encoding="utf-8"))
        target_row = target_external[target_external.evaluation_set.str.contains(f"{minutes} minutes")].iloc[0]
        actual = float(actual_row["auprc"])
        delta = difference(actual, target_row.auprc)
        report["checks"][f"external_{minutes}min"] = {"auprc": actual, "target": float(target_row.auprc), "difference": delta}
        if minutes == 30 and abs(delta) > args.primary_tolerance:
            report["status"] = "review_required"

    report_path = output / "empirical_target_comparison.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    if report["status"] != "passed":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
