**Table 14. Interpretability and representation diagnostics**

|diagnostic|feature_or_prefix_stratum|estimate|fold_sd|
|---|---|---|---|
|Normalized absolute attribution|Recent cart event|0.214|0.018|
|Normalized absolute attribution|Repeated-item relation|0.176|0.015|
|Normalized absolute attribution|Cumulative cart count|0.148|0.013|
|Normalized absolute attribution|Time since last event|0.126|0.011|
|Normalized absolute attribution|Unique-item ratio|0.111|0.010|
|Normalized absolute attribution|Active duration|0.089|0.009|
|Normalized absolute attribution|All remaining features|0.136|0.014|
|Sequence-fusion weight alpha|Prefix-length Q1|0.380|0.041|
|Sequence-fusion weight alpha|Prefix-length Q2|0.470|0.038|
|Sequence-fusion weight alpha|Prefix-length Q3|0.560|0.036|
|Sequence-fusion weight alpha|Prefix-length Q4|0.640|0.039|
