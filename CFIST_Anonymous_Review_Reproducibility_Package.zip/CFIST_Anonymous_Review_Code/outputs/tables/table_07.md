**Table 7. Internal and strict zero-shot external-validation matrix**

|evaluation_set|sessions|positive_prevalence|auprc|auprc_ci_low|auprc_ci_high|auroc|auroc_ci_low|auroc_ci_high|brier|brier_ci_low|brier_ci_high|ece|ece_ci_low|ece_ci_high|calibration_slope|calibration_slope_ci_low|calibration_slope_ci_high|calibration_intercept|calibration_intercept_ci_low|calibration_intercept_ci_high|selective_brier_80|selective_brier_80_ci_low|selective_brier_80_ci_high|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|OTTO concatenated OOF|7090394|0.108|0.487|0.485|0.489|0.879|0.878|0.880|0.068|0.067|0.069|0.016|0.015|0.017|0.984|0.973|0.995|0.006|-0.002|0.014|0.052|0.051|0.053|
|Retailrocket zero-shot, 30 minutes|372846|0.042|0.251|0.247|0.255|0.831|0.828|0.834|0.029|0.028|0.030|0.026|0.024|0.028|0.842|0.824|0.861|-0.214|-0.242|-0.187|0.021|0.020|0.022|
|Retailrocket zero-shot, 15 minutes|338104|0.039|0.238|0.234|0.242|0.824|0.821|0.827|0.028|0.027|0.029|0.029|0.027|0.031|0.818|0.798|0.838|-0.237|-0.266|-0.208|0.021|0.020|0.022|
|Retailrocket zero-shot, 60 minutes|389557|0.044|0.257|0.253|0.261|0.835|0.832|0.838|0.030|0.029|0.031|0.027|0.025|0.029|0.851|0.833|0.869|-0.198|-0.225|-0.171|0.022|0.021|0.023|
