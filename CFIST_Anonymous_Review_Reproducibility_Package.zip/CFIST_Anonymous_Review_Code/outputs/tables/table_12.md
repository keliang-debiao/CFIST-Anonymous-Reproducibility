**Table 12. Low-data and prevalence-shift analyses**

|analysis|level|positive_prevalence|cfist_auprc|auroc|ece|comparator_or_interpretation|
|---|---|---|---|---|---|---|
|Training fraction|1%|0.108|0.403|0.842|0.025|CausalMixFT plus FT-Transformer AUPRC 0.395|
|Training fraction|5%|0.108|0.438|0.858|0.021|CausalMixFT plus FT-Transformer AUPRC 0.429|
|Training fraction|10%|0.108|0.453|0.866|0.019|CausalMixFT plus FT-Transformer AUPRC 0.446|
|Training fraction|25%|0.108|0.469|0.873|0.018|No augmentation comparator was prespecified|
|Training fraction|50%|0.108|0.479|0.877|0.017|No augmentation comparator was prespecified|
|Training fraction|100%|0.108|0.487|0.879|0.016|Primary internal result|
|Prior resampling|5%|0.050|0.318|0.876|0.031|AUPRC decreases with event prevalence|
|Prior resampling|15%|0.150|0.580|0.881|0.024|AUROC remains comparatively stable|
