**Table 10. Calibration and selective-risk results**

|condition|dataset|brier_100|brier_100_ci_low|brier_100_ci_high|ece|ece_ci_low|ece_ci_high|slope|slope_ci_low|slope_ci_high|intercept|intercept_ci_low|intercept_ci_high|selective_brier_80|selective_brier_80_ci_low|selective_brier_80_ci_high|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|CFIST before temperature scaling|OTTO OOF|0.070|0.069|0.071|0.028|0.026|0.030|0.941|0.928|0.954|0.021|0.015|0.027|0.054|0.053|0.055|
|CFIST after frozen temperature scaling|OTTO OOF|0.068|0.067|0.069|0.016|0.015|0.017|0.984|0.973|0.995|0.006|-0.002|0.014|0.052|0.051|0.053|
|LightGBM after frozen scaling|OTTO OOF|0.067|0.066|0.068|0.014|0.013|0.015|0.991|0.979|1.003|0.003|-0.003|0.009|0.053|0.052|0.054|
|CFIST frozen zero-shot|Retailrocket|0.029|0.028|0.030|0.026|0.024|0.028|0.842|0.824|0.861|-0.214|-0.242|-0.187|0.021|0.020|0.022|
