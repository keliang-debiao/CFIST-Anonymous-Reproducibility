**Table 15. Computational efficiency and reproducibility profile**

|model|parameters_m|flops_g|training_hours_median|training_hours_q1|training_hours_q3|inference_ms_per_1000_median|inference_ms_per_1000_q1|inference_ms_per_1000_q3|peak_memory_median|peak_memory_q1|peak_memory_q3|environment|memory_unit|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|LightGBM|||1.600|1.500|1.700|12.400|12.000|12.800|18.600|18.100|19.000|32-core CPU; same cohort|GB CPU RAM|
|FT-Transformer|2.800|0.740|2.100|2.000|2.200|16.800|16.300|17.200|4.200|4.000|4.400|Single RTX 4090|GB|
|TRON-backbone|3.100|0.830|2.500|2.400|2.700|19.500|19.000|20.100|4.800|4.600|5.000|Single RTX 4090|GB|
|PTE-GT-backbone|3.700|1.050|3.100|3.000|3.300|25.400|24.800|26.100|5.600|5.400|5.800|Single RTX 4090|GB|
|CFIST|4.300|1.180|3.400|3.300|3.600|28.700|28.100|29.400|6.200|6.000|6.400|Single RTX 4090|GB|
