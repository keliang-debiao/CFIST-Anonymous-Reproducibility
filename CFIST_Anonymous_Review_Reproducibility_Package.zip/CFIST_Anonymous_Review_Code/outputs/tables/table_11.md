**Table 11. Robustness comparison under matched input perturbations**

|condition|severity|cfist_auprc|cfist_auprc_ci_low|cfist_auprc_ci_high|pte_gt_auprc|pte_gt_auprc_ci_low|pte_gt_auprc_ci_high|absolute_advantage|cfist_brier|cfist_ece|
|---|---|---|---|---|---|---|---|---|---|---|
|Unperturbed||0.487|0.485|0.489|0.472|0.470|0.474|0.015|0.068|0.016|
|Random event deletion|10%|0.478|0.476|0.480|0.459|0.457|0.461|0.019|0.069|0.018|
|Random event deletion|30%|0.452|0.450|0.454|0.426|0.424|0.428|0.026|0.073|0.023|
|Random event deletion|50%|0.411|0.409|0.413|0.379|0.377|0.381|0.032|0.080|0.031|
|Timestamp noise|10% of median gap|0.480|0.478|0.482|0.462|0.460|0.464|0.018|0.070|0.019|
|Stage-map input noise|10%|0.459|0.457|0.461|0.431|0.429|0.433|0.028|0.076|0.026|
|Reduced training data|50%|0.479|0.477|0.481|0.458|0.456|0.460|0.021|0.069|0.017|
|Strict external transfer|Retailrocket, 30 minutes|0.251|0.247|0.255|0.228|0.224|0.232|0.023|0.029|0.026|
