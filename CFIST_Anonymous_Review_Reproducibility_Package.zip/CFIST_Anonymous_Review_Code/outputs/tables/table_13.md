**Table 13. Paired statistical comparisons**

|comparator_or_analysis|estimand|estimate|ci_low|ci_high|raw_p|holm_adjusted_p|effect_size|
|---|---|---|---|---|---|---|---|
|LightGBM|AUPRC difference|0.029|0.025|0.033|<0.001|<0.001|6.3% relative gain|
|FT-Transformer|AUPRC difference|0.032|0.028|0.036|<0.001|<0.001|7.0% relative gain|
|TabICLv2|AUPRC difference|0.025|0.021|0.029|<0.001|<0.001|5.4% relative gain|
|TRON-backbone|AUPRC difference|0.021|0.017|0.025|<0.001|<0.001|4.5% relative gain|
|PTE-GT-backbone|AUPRC difference|0.015|0.010|0.020|0.001|0.013|3.2% relative gain|
|LightGBM|Brier difference; positive favors LightGBM|0.001|0.000|0.002|0.021|0.084|1.5% relative error increase|
|No relational tokenizer, external|AUPRC difference|0.033|0.027|0.039|<0.001|<0.001|15.1% relative gain|
|Structural-only uncertainty|Selective Brier AURC difference|-0.006|-0.008|-0.004|<0.001|<0.001|10.3% relative risk-area reduction|
