**Table 8. Published studies using the same public datasets or closely related session tasks**

|study|dataset_and_scale|task|validation_protocol|model|metric|published_result|comparability|
|---|---|---|---|---|---|---|---|
|OTTO official baseline report [28]|OTTO; 216,716,096 training events|Session-based next-item ranking|Official offline protocol|GRU4Rec+|Recall@20; MRR@20|0.443; 0.205|Contextual only; different label and metric|
|OTTO official baseline report [28]|Same OTTO release|Session-based next-item ranking|Official offline protocol|SASRec|Recall@20; MRR@20|0.307; 0.180|Contextual only; different label and metric|
|Wilm et al. 2023 [41]|OTTO; 216,716,096 training events|Next-item ranking and live recommendation|Paper-specific offline split plus live A/B test|TRON|Recall@20; MRR@20; live CTR|0.472; 0.219; 18.14% live CTR lift over SASRec|Contextual only; different endpoint and deployment protocol|
|Chakrabarty and Pal 2026 [25]|Retailrocket; 2,756,101 events|Long-sequence next-item recommendation|Paper-defined long-sequence split|Sliding-window framework|MRR; Recall@10|Up to 6.04% and 6.34% relative improvement|Contextual only; binary future order is not evaluated|
|Current study|OTTO development plus Retailrocket external|Future first order after the retrospective midpoint prefix of a completed session|Five rolling folds plus frozen zero-shot external test|CFIST|AUPRC; AUROC; Brier; ECE|Internal 0.487 AUPRC; external 0.251 AUPRC|No direct numerical superiority claim because the protocol differs|
