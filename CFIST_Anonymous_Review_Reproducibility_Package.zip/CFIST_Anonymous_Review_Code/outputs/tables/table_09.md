**Table 9. Component and objective ablations of CFIST**

|variant|auprc_mean|auprc_sd|paired_change|change_ci_low|change_ci_high|brier|external_auprc|selective_brier_aurc|holm_adjusted_p|relative_auprc_loss_pct|
|---|---|---|---|---|---|---|---|---|---|---|
|Full CFIST|0.487|0.009|0.000|0.000|0.000|0.068|0.251|0.052||0.000|
|Without relational tokenization|0.471|0.010|-0.016|-0.020|-0.012|0.070|0.218|0.056|<0.001|3.300|
|Without funnel biases|0.476|0.010|-0.011|-0.014|-0.008|0.069|0.239|0.055|<0.001|2.300|
|Without feature graph|0.480|0.010|-0.007|-0.010|-0.004|0.069|0.243|0.054|0.018|1.400|
|Fixed fusion weight|0.482|0.010|-0.005|-0.008|-0.002|0.069|0.245|0.054|0.084|1.000|
|Without Group DRO|0.478|0.010|-0.009|-0.012|-0.006|0.069|0.232|0.055|<0.001|1.800|
|Without prefix consistency|0.483|0.010|-0.004|-0.007|-0.001|0.068|0.244|0.053|0.099|0.800|
|Without next-stage objective|0.481|0.010|-0.006|-0.009|-0.003|0.069|0.242|0.054|0.035|1.200|
|Structural uncertainty only|0.486|0.009|-0.001|-0.003|0.001|0.068|0.250|0.058|1.000|0.200|
|Contextual uncertainty only|0.486|0.009|-0.001|-0.003|0.001|0.068|0.249|0.056|1.000|0.200|
|Without uncertainty objective|0.485|0.009|-0.002|-0.004|0.000|0.068|0.248|0.061|0.612|0.400|
|Simplified chronological-Transformer backbone|0.463|0.011|-0.024|-0.029|-0.019|0.071|0.221|0.060|<0.001|4.900|
