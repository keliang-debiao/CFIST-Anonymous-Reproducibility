from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np
from scipy.optimize import minimize, minimize_scalar
from scipy.special import expit, logit


def _binary_nll_from_logits(logits: np.ndarray, labels: np.ndarray) -> float:
    logits = np.asarray(logits, dtype=np.float64)
    labels = np.asarray(labels, dtype=np.float64)
    return float(np.mean(np.logaddexp(0.0, logits) - labels * logits))


@dataclass
class TemperatureScaler:
    temperature: float = 1.0

    def fit(self, logits: np.ndarray, labels: np.ndarray) -> "TemperatureScaler":
        logits = np.asarray(logits, dtype=np.float64)
        labels = np.asarray(labels, dtype=np.float64)
        result = minimize_scalar(
            lambda log_t: _binary_nll_from_logits(logits / np.exp(log_t), labels),
            bounds=(-4.0, 4.0),
            method="bounded",
        )
        if not result.success:
            raise RuntimeError(f"Temperature optimization failed: {result.message}")
        self.temperature = float(np.exp(result.x))
        return self

    def transform_logits(self, logits: np.ndarray) -> np.ndarray:
        return np.asarray(logits, dtype=np.float64) / self.temperature

    def transform_probability(self, probability: np.ndarray) -> np.ndarray:
        p = np.clip(np.asarray(probability, dtype=np.float64), 1e-7, 1 - 1e-7)
        return expit(logit(p) / self.temperature)

    def to_dict(self) -> dict:
        return asdict(self)


def _huber(residual: np.ndarray, delta: float = 1.0) -> np.ndarray:
    absolute = np.abs(residual)
    return np.where(absolute <= delta, 0.5 * residual**2, delta * (absolute - 0.5 * delta))


@dataclass
class UncertaintyCombiner:
    beta0: float = 0.0
    beta1: float = 1.0
    beta2: float = 1.0
    tau: float = 8.0

    def fit(
        self,
        *,
        error_proxy: np.ndarray,
        prefix_length: np.ndarray,
        contextual_distance: np.ndarray,
        probability: np.ndarray,
        labels: np.ndarray,
        mode: str = "dual",
    ) -> "UncertaintyCombiner":
        proxy = np.asarray(error_proxy, dtype=np.float64)
        length = np.asarray(prefix_length, dtype=np.float64)
        context = np.asarray(contextual_distance, dtype=np.float64)
        target = np.square(np.asarray(labels) - np.asarray(probability))

        if mode not in {"dual", "structural", "contextual"}:
            raise ValueError("mode must be dual, structural, or contextual")

        def objective(parameters):
            beta0, beta1_raw, beta2_raw, eta_tau = parameters
            beta1 = 0.0 if mode == "contextual" else np.log1p(np.exp(beta1_raw))
            beta2 = 0.0 if mode == "structural" else np.log1p(np.exp(beta2_raw))
            tau = np.log1p(np.exp(eta_tau)) + 1e-6
            structural = proxy + np.exp(-length / tau)
            prediction = expit(beta0 + beta1 * structural + beta2 * np.log1p(context))
            return float(np.mean(_huber(prediction - target)))

        result = minimize(objective, x0=np.array([0.0, 0.0, 0.0, 2.0]), method="L-BFGS-B")
        if not result.success:
            raise RuntimeError(f"Uncertainty-combiner optimization failed: {result.message}")
        beta0, beta1_raw, beta2_raw, eta_tau = result.x
        self.beta0 = float(beta0)
        self.beta1 = 0.0 if mode == "contextual" else float(np.log1p(np.exp(beta1_raw)))
        self.beta2 = 0.0 if mode == "structural" else float(np.log1p(np.exp(beta2_raw)))
        self.tau = float(np.log1p(np.exp(eta_tau)) + 1e-6)
        return self

    def transform(self, error_proxy, prefix_length, contextual_distance) -> tuple[np.ndarray, np.ndarray]:
        structural = np.asarray(error_proxy) + np.exp(-np.asarray(prefix_length) / self.tau)
        combined = expit(
            self.beta0
            + self.beta1 * structural
            + self.beta2 * np.log1p(np.asarray(contextual_distance))
        )
        return structural, combined

    def to_dict(self) -> dict:
        return asdict(self)
