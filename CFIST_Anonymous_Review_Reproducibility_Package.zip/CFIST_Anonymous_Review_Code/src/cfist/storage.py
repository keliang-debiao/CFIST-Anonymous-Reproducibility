from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

from .cohort import SessionExample


def require_pyarrow():
    try:
        import pyarrow as pa
        import pyarrow.parquet as pq
    except ImportError as exc:
        raise RuntimeError("pyarrow is required for prepared session storage") from exc
    return pa, pq


class ShardedSessionWriter:
    def __init__(self, output_dir: str | Path, rows_per_shard: int = 100_000):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.rows_per_shard = int(rows_per_shard)
        self.buffer: list[dict] = []
        self.shard_index = 0
        self.rows_written = 0

    def append(self, example: SessionExample) -> None:
        self.buffer.append(example.to_dict())
        if len(self.buffer) >= self.rows_per_shard:
            self.flush()

    def flush(self) -> None:
        if not self.buffer:
            return
        pa, pq = require_pyarrow()
        table = pa.Table.from_pylist(self.buffer)
        path = self.output_dir / f"sessions-{self.shard_index:05d}.parquet"
        pq.write_table(table, path, compression="zstd", use_dictionary=True)
        self.rows_written += len(self.buffer)
        self.shard_index += 1
        self.buffer.clear()

    def close(self) -> dict:
        self.flush()
        manifest = {
            "rows": self.rows_written,
            "shards": self.shard_index,
            "format": "parquet",
        }
        with (self.output_dir / "manifest.json").open("w", encoding="utf-8") as handle:
            json.dump(manifest, handle, indent=2)
        return manifest


def iter_session_rows(dataset_dir: str | Path, columns: list[str] | None = None) -> Iterable[dict]:
    try:
        import pyarrow.dataset as ds
    except ImportError as exc:
        raise RuntimeError("pyarrow is required for prepared session storage") from exc
    dataset = ds.dataset(str(dataset_dir), format="parquet")
    scanner = dataset.scanner(columns=columns, batch_size=4096, use_threads=True)
    for batch in scanner.to_batches():
        yield from batch.to_pylist()
