from __future__ import annotations

import copy
import math
from collections.abc import Callable

import numpy as np


def log_uniform(rng: np.random.Generator, lower: float, upper: float) -> float:
    return float(np.exp(rng.uniform(np.log(lower), np.log(upper))))


def candidate_configurations(config: dict, seed: int) -> list[dict]:
    selection = config["selection"]
    rng = np.random.default_rng(seed)
    candidates = []
    for trial in range(int(selection["trials"])):
        candidate = copy.deepcopy(config)
        candidate["optimization"]["learning_rate"] = float(rng.choice(selection["learning_rates"]))
        candidate["optimization"]["weight_decay"] = float(rng.choice(selection["weight_decays"]))
        lower, upper = map(float, selection["auxiliary_coefficient_range"])
        candidate["optimization"]["lambda_stage"] = log_uniform(rng, lower, upper)
        candidate["optimization"]["lambda_prefix"] = log_uniform(rng, lower, upper)
        candidate["optimization"]["lambda_uncertainty"] = log_uniform(rng, lower, upper)
        candidate["selection_record"] = {"trial": trial, "seed": seed}
        candidates.append(candidate)
    return candidates


def expanding_inner_splits(blocks: list[int], n_splits: int) -> list[tuple[set[int], set[int]]]:
    ordered = sorted(set(blocks))
    if len(ordered) < 2:
        raise ValueError("Nested chronological selection requires at least two historical blocks")
    possible = [(set(ordered[:index]), {ordered[index]}) for index in range(1, len(ordered))]
    if len(possible) <= n_splits:
        return possible
    selected = np.linspace(0, len(possible) - 1, n_splits, dtype=int)
    return [possible[index] for index in selected]


def chronological_random_search(
    config: dict,
    historical_blocks: list[int],
    evaluator: Callable[[dict, set[int], set[int]], float],
    seed: int,
) -> tuple[dict, list[dict]]:
    splits = expanding_inner_splits(historical_blocks, int(config["selection"]["inner_temporal_splits"]))
    records = []
    best_score = -math.inf
    best_config = None
    for candidate in candidate_configurations(config, seed):
        scores = [evaluator(candidate, train, validation) for train, validation in splits]
        mean_score = float(np.mean(scores))
        records.append({
            "trial": candidate["selection_record"]["trial"],
            "mean_auprc": mean_score,
            "split_auprc": scores,
            "optimization": candidate["optimization"],
        })
        if mean_score > best_score:
            best_score = mean_score
            best_config = candidate
    if best_config is None:
        raise RuntimeError("No hyperparameter candidate completed")
    return best_config, records
