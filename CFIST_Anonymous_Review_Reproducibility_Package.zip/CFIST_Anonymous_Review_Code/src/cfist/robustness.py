from __future__ import annotations

import math

import numpy as np


def _relation_features(stage: np.ndarray, item: np.ndarray, gap: np.ndarray, elapsed: np.ndarray) -> np.ndarray:
    length = len(stage)
    output = np.zeros((length, 10), dtype=np.float32)
    counts: dict[int, int] = {}
    last_elapsed: dict[int, float] = {}
    clicks = 0
    carts = 0
    for index in range(length):
        code = int(item[index])
        prior = counts.get(code, 0)
        if int(stage[index]) == 0:
            clicks += 1
        elif int(stage[index]) == 1:
            carts += 1
        counts[code] = prior + 1
        since = 0.0 if prior == 0 else max(0.0, float(elapsed[index]) - last_elapsed[code])
        last_elapsed[code] = float(elapsed[index])
        unique = len(counts)
        position = index + 1
        output[index] = [
            float(prior == 0),
            float(index > 0 and code == int(item[index - 1])),
            math.log1p(prior),
            math.log1p(since),
            math.log1p(clicks),
            math.log1p(carts),
            math.log1p(unique),
            unique / position,
            (position - unique) / position,
            position / length,
        ]
    return output


def _graph_features(stage: np.ndarray, item: np.ndarray, gap: np.ndarray, elapsed: np.ndarray) -> np.ndarray:
    length = len(stage)
    unique = len(set(map(int, item.tolist())))
    carts = np.flatnonzero(stage == 1)
    first_cart = int(carts[0]) if len(carts) else None
    post_cart_click = int(np.sum(stage[first_cart + 1 :] == 0)) if first_cart is not None else 0
    noninitial = gap[1:] if length > 1 else np.array([0.0])
    return np.asarray([
        length,
        unique,
        (length - unique) / length,
        np.sum(stage == 0),
        np.sum(stage == 1),
        post_cart_click,
        np.mean(noninitial),
        gap[-1],
        elapsed[-1] - elapsed[0],
    ], dtype=np.float64)


def perturb_collated_batch(batch: dict, condition: str, severity: float, seed: int, preprocessor) -> dict:
    import torch

    rng = np.random.default_rng(seed)
    output = {key: value.clone() if torch.is_tensor(value) else list(value) if isinstance(value, list) else value for key, value in batch.items()}
    for row in range(output["stage_ids"].shape[0]):
        length = int(batch["attention_mask"][row].sum().item())
        stage = batch["stage_ids"][row, :length].cpu().numpy().copy()
        item = batch["item_codes"][row, :length].cpu().numpy().copy()
        gap = batch["gap_seconds"][row, :length].cpu().numpy().copy()
        elapsed = batch["elapsed_seconds"][row, :length].cpu().numpy().copy()

        if condition == "event_deletion":
            retained = max(1, int(round(length * (1.0 - severity))))
            selected = np.sort(rng.choice(length, size=retained, replace=False))
            stage, item, elapsed = stage[selected], item[selected], elapsed[selected]
            elapsed = elapsed - elapsed[0]
            gap = np.concatenate([[0.0], np.diff(elapsed)])
        elif condition == "timestamp_noise":
            positive = gap[gap > 0]
            scale = severity * (float(np.median(positive)) if len(positive) else 1.0)
            gap = np.clip(gap + rng.normal(0.0, scale, size=len(gap)), 0.0, None)
            elapsed = np.cumsum(gap)
        elif condition == "stage_noise":
            count = int(round(severity * length))
            if count:
                selected = rng.choice(length, size=count, replace=False)
                stage[selected] = rng.integers(0, 3, size=count)
        elif condition != "unperturbed":
            raise ValueError(f"Unsupported condition: {condition}")

        new_length = len(stage)
        relation = _relation_features(stage, item, gap, elapsed)
        graph = preprocessor.transform_graph(_graph_features(stage, item, gap, elapsed))
        gap_bin = preprocessor.transform_gaps(gap)
        width = output["stage_ids"].shape[1]
        for key, fill in (("stage_ids", 0), ("item_codes", -1), ("gap_bins", 0)):
            output[key][row].fill_(fill)
        for key in ("gap_seconds", "elapsed_seconds", "relations"):
            output[key][row].zero_()
        output["attention_mask"][row].zero_()
        output["stage_ids"][row, :new_length] = torch.as_tensor(stage, device=output["stage_ids"].device)
        output["item_codes"][row, :new_length] = torch.as_tensor(item, device=output["item_codes"].device)
        output["gap_bins"][row, :new_length] = torch.as_tensor(gap_bin, device=output["gap_bins"].device)
        output["gap_seconds"][row, :new_length] = torch.as_tensor(gap, device=output["gap_seconds"].device)
        output["elapsed_seconds"][row, :new_length] = torch.as_tensor(elapsed, device=output["elapsed_seconds"].device)
        output["relations"][row, :new_length] = torch.as_tensor(relation, device=output["relations"].device)
        output["attention_mask"][row, :new_length] = True
        output["graph_features"][row] = torch.as_tensor(graph, device=output["graph_features"].device)
        output["prefix_length"][row] = float(new_length)
        if new_length < width:
            output["adjacent_graph_features"][row] = output["graph_features"][row]
    return output
