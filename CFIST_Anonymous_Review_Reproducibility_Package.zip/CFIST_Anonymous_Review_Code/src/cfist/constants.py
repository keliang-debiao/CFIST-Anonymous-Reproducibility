from __future__ import annotations

STAGE_TO_ID = {"click": 0, "cart": 1, "order": 2}
ID_TO_STAGE = {value: key for key, value in STAGE_TO_ID.items()}

SOURCE_STAGE_MAP = {
    "otto": {"click": "click", "cart": "cart", "order": "order"},
    "retailrocket": {"view": "click", "addtocart": "cart", "transaction": "order"},
}

RELATION_FEATURE_NAMES = (
    "first_occurrence",
    "same_as_previous_item",
    "log_recurrence_count",
    "log_time_since_item",
    "log_cumulative_clicks",
    "log_cumulative_carts",
    "log_unique_items",
    "session_novelty",
    "repeat_ratio",
    "normalized_position",
)

GRAPH_FEATURE_NAMES = (
    "prefix_length",
    "unique_items",
    "repeat_ratio",
    "click_count",
    "cart_count",
    "post_cart_click_count",
    "mean_gap_seconds",
    "latest_gap_seconds",
    "active_duration_seconds",
)

DEFAULT_SEEDS = (104729, 130363, 155921, 196613, 262147)
