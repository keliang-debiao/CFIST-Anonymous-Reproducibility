from __future__ import annotations

from collections.abc import Callable

import numpy as np


def cluster_bootstrap(
    *,
    labels: np.ndarray,
    predictions: np.ndarray,
    clusters: np.ndarray,
    statistic: Callable[[np.ndarray, np.ndarray], float],
    resamples: int = 2000,
    seed: int = 271828,
) -> tuple[float, tuple[float, float], np.ndarray]:
    y = np.asarray(labels)
    p = np.asarray(predictions)
    group = np.asarray(clusters)
    unique, inverse = np.unique(group, return_inverse=True)
    members = [np.flatnonzero(inverse == idx) for idx in range(len(unique))]
    rng = np.random.default_rng(seed)
    values = np.empty(resamples, dtype=np.float64)
    for iteration in range(resamples):
        selected = rng.integers(0, len(unique), size=len(unique))
        index = np.concatenate([members[position] for position in selected])
        values[iteration] = statistic(y[index], p[index])
    estimate = float(statistic(y, p))
    interval = tuple(np.quantile(values, [0.025, 0.975]).astype(float))
    return estimate, interval, values


def paired_cluster_bootstrap_difference(
    *,
    labels: np.ndarray,
    predictions_a: np.ndarray,
    predictions_b: np.ndarray,
    clusters: np.ndarray,
    statistic: Callable[[np.ndarray, np.ndarray], float],
    resamples: int = 2000,
    seed: int = 271828,
) -> tuple[float, tuple[float, float], float, np.ndarray]:
    y = np.asarray(labels)
    a = np.asarray(predictions_a)
    b = np.asarray(predictions_b)
    group = np.asarray(clusters)
    unique, inverse = np.unique(group, return_inverse=True)
    members = [np.flatnonzero(inverse == idx) for idx in range(len(unique))]
    rng = np.random.default_rng(seed)
    values = np.empty(resamples, dtype=np.float64)
    for iteration in range(resamples):
        selected = rng.integers(0, len(unique), size=len(unique))
        index = np.concatenate([members[position] for position in selected])
        values[iteration] = statistic(y[index], a[index]) - statistic(y[index], b[index])
    estimate = float(statistic(y, a) - statistic(y, b))
    interval = tuple(np.quantile(values, [0.025, 0.975]).astype(float))
    lower_tail = (np.sum(values <= 0.0) + 1) / (resamples + 1)
    upper_tail = (np.sum(values >= 0.0) + 1) / (resamples + 1)
    p_value = float(min(1.0, 2.0 * min(lower_tail, upper_tail)))
    return estimate, interval, p_value, values


def holm_adjust(p_values: list[float]) -> list[float]:
    p = np.asarray(p_values, dtype=np.float64)
    order = np.argsort(p)
    adjusted = np.empty_like(p)
    running = 0.0
    count = len(p)
    for rank, index in enumerate(order):
        candidate = (count - rank) * p[index]
        running = max(running, candidate)
        adjusted[index] = min(1.0, running)
    return adjusted.tolist()
