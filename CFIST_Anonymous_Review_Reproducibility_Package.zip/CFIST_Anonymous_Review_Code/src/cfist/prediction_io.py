from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


PREDICTION_COLUMNS = (
    "entity_id",
    "group_id",
    "label",
    "logit",
    "probability",
    "probability_calibrated",
    "error_proxy",
    "uncertainty_structural",
    "uncertainty_contextual",
    "uncertainty_combined",
    "accepted_0.80",
    "fusion_weight",
    "prefix_length",
    "environment",
)


def write_predictions(predictions: dict[str, np.ndarray], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame({key: predictions[key] for key in PREDICTION_COLUMNS if key in predictions})
    frame.to_parquet(path, index=False, compression="zstd")


def read_predictions(path: str | Path) -> dict[str, np.ndarray]:
    frame = pd.read_parquet(path)
    return {column: frame[column].to_numpy() for column in frame.columns}


def write_state(state, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(state.to_dict(), handle, indent=2)
