from __future__ import annotations

import numpy as np

from .metrics import binary_metrics
from .training import move_batch


def fit_binary_network(model, training_loader, development_loader, config, positive_weight, device):
    import torch

    optimization = config["optimization"]
    model.to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(optimization["learning_rate"]),
        weight_decay=float(optimization["weight_decay"]),
    )
    best_state = None
    best_auprc = -np.inf
    patience = 0
    for _ in range(int(optimization["epochs"])):
        model.train()
        for batch in training_loader:
            batch = move_batch(batch, device)
            optimizer.zero_grad(set_to_none=True)
            logits = model(batch)
            loss = torch.nn.functional.binary_cross_entropy_with_logits(
                logits, batch["label"], pos_weight=torch.as_tensor(positive_weight, device=device)
            )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), float(optimization["gradient_clip_norm"]))
            optimizer.step()
        predictions = predict_binary_network(model, development_loader, device)
        score = binary_metrics(predictions["label"], predictions["probability"])["auprc"]
        if score > best_auprc:
            best_auprc = score
            best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
            patience = 0
        else:
            patience += 1
            if patience >= int(optimization["early_stopping_patience"]):
                break
    if best_state is None:
        raise RuntimeError("Baseline training did not produce a checkpoint")
    model.load_state_dict(best_state)
    return model


def predict_binary_network(model, loader, device):
    import torch

    model.eval()
    labels, probabilities, entities, groups = [], [], [], []
    with torch.inference_mode():
        for batch in loader:
            entities.extend(batch["entity_id"])
            groups.extend(batch["group_id"])
            batch = move_batch(batch, device)
            logits = model(batch)
            labels.append(batch["label"].cpu().numpy())
            probabilities.append(torch.sigmoid(logits).cpu().numpy())
    return {
        "entity_id": np.asarray(entities, dtype=object),
        "group_id": np.asarray(groups, dtype=object),
        "label": np.concatenate(labels),
        "probability": np.concatenate(probabilities),
    }
