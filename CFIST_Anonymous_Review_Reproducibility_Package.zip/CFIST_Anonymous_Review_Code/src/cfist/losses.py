from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class GroupDRO(nn.Module):
    def __init__(self, environments: int, eta: float = 0.01, regularization: float = 0.001, minimum_samples: int = 32):
        super().__init__()
        self.eta = float(eta)
        self.regularization = float(regularization)
        self.minimum_samples = int(minimum_samples)
        self.register_buffer("weights", torch.ones(environments) / environments)

    def forward(self, per_sample_loss: torch.Tensor, environment: torch.Tensor) -> tuple[torch.Tensor, dict[int, float]]:
        risks = []
        active = []
        diagnostics: dict[int, float] = {}
        for env in range(len(self.weights)):
            mask = environment == env
            if int(mask.sum()) >= self.minimum_samples:
                risk = per_sample_loss[mask].mean()
                risks.append(risk)
                active.append(env)
                diagnostics[env] = float(risk.detach().cpu())
        if not risks:
            return per_sample_loss.mean(), diagnostics
        risk_tensor = torch.stack(risks)
        active_index = torch.as_tensor(active, device=per_sample_loss.device)
        active_weights = self.weights[active_index]
        if self.training:
            with torch.no_grad():
                updated = active_weights * torch.exp(self.eta * risk_tensor.detach())
                updated = (updated + self.regularization) / (updated + self.regularization).sum()
                self.weights[active_index] = updated
                self.weights /= self.weights.sum()
        normalized = self.weights[active_index] / self.weights[active_index].sum()
        return torch.sum(normalized * risk_tensor), diagnostics


def weighted_binary_loss(logits, labels, positive_weight: float, negative_weight: float):
    base = F.binary_cross_entropy_with_logits(logits, labels, reduction="none")
    weights = torch.where(labels > 0.5, positive_weight, negative_weight)
    return base * weights


def bernoulli_js(probability_a: torch.Tensor, probability_b: torch.Tensor) -> torch.Tensor:
    eps = torch.finfo(probability_a.dtype).eps
    a = torch.stack([probability_a, 1 - probability_a], dim=-1).clamp(eps, 1 - eps)
    b = torch.stack([probability_b, 1 - probability_b], dim=-1).clamp(eps, 1 - eps)
    midpoint = 0.5 * (a + b)
    kl_a = torch.sum(a * (torch.log(a) - torch.log(midpoint)), dim=-1)
    kl_b = torch.sum(b * (torch.log(b) - torch.log(midpoint)), dim=-1)
    return 0.5 * (kl_a + kl_b)


def adjacent_prefix_loss(short_output, long_output, valid_mask: torch.Tensor) -> torch.Tensor:
    if not bool(valid_mask.any()):
        return long_output.purchase_logit.new_zeros(())
    representation_loss = F.mse_loss(
        short_output.representation[valid_mask],
        long_output.representation[valid_mask].detach(),
    )
    probability_loss = bernoulli_js(
        short_output.probability[valid_mask],
        long_output.probability[valid_mask].detach(),
    ).mean()
    return representation_loss + probability_loss


def next_stage_loss(logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
    valid = targets >= 0
    if not bool(valid.any()):
        return logits.new_zeros(())
    return F.cross_entropy(logits[valid], targets[valid])


def uncertainty_proxy_loss(error_proxy, probability, labels):
    target = (labels - probability.detach()).square()
    return F.huber_loss(error_proxy, target)


def complete_objective(
    *,
    output,
    short_output,
    batch,
    adjacent_valid,
    group_dro: GroupDRO | None,
    positive_weight: float,
    negative_weight: float,
    lambda_stage: float,
    lambda_prefix: float,
    lambda_uncertainty: float,
) -> tuple[torch.Tensor, dict[str, float]]:
    purchase_per_sample = weighted_binary_loss(
        output.purchase_logit,
        batch["label"],
        positive_weight,
        negative_weight,
    )
    if group_dro is None:
        purchase = purchase_per_sample.mean()
        environment_risk = {}
    else:
        purchase, environment_risk = group_dro(purchase_per_sample, batch["environment"])
    stage = next_stage_loss(output.next_stage_logits, batch["next_stage"])
    prefix = adjacent_prefix_loss(short_output, output, adjacent_valid)
    uncertainty = uncertainty_proxy_loss(output.error_proxy, output.probability, batch["label"])
    total = purchase + lambda_stage * stage + lambda_prefix * prefix + lambda_uncertainty * uncertainty
    diagnostics = {
        "loss_total": float(total.detach().cpu()),
        "loss_purchase": float(purchase.detach().cpu()),
        "loss_stage": float(stage.detach().cpu()),
        "loss_prefix": float(prefix.detach().cpu()),
        "loss_uncertainty": float(uncertainty.detach().cpu()),
        **{f"environment_{key}_risk": value for key, value in environment_risk.items()},
    }
    return total, diagnostics
