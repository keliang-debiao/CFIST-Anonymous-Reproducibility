from __future__ import annotations

from collections.abc import Iterable, Iterator

from .schema import RawEvent


def sessionize_visitor_events(
    visitor_id: str,
    events: Iterable[RawEvent],
    inactivity_minutes: int = 30,
) -> Iterator[tuple[str, list[RawEvent]]]:
    ordered = sorted(events, key=lambda row: (row.timestamp, row.item_id, row.stage))
    if not ordered:
        return
    threshold_seconds = inactivity_minutes * 60
    current = [ordered[0]]
    session_number = 0
    for event in ordered[1:]:
        if event.timestamp - current[-1].timestamp > threshold_seconds:
            yield f"{visitor_id}:{session_number}", current
            session_number += 1
            current = [event]
        else:
            current.append(event)
    yield f"{visitor_id}:{session_number}", current
