from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np

from .storage import iter_session_rows
from .sampling import deterministic_include


@dataclass
class FoldPreprocessor:
    gap_edges: list[float]
    graph_median: list[float]
    graph_iqr: list[float]
    positive_weight: float
    negative_weight: float
    fitted_fold: int

    @classmethod
    def fit(
        cls,
        *,
        gap_values: np.ndarray,
        graph_features: np.ndarray,
        labels: np.ndarray,
        fold: int,
        gap_bins: int = 16,
    ) -> "FoldPreprocessor":
        gaps = np.log1p(np.clip(np.asarray(gap_values, dtype=np.float64), 0, None))
        quantiles = np.linspace(0, 1, gap_bins + 1)[1:-1]
        edges = np.unique(np.quantile(gaps, quantiles)).tolist()
        graph = np.asarray(graph_features, dtype=np.float64)
        median = np.nanmedian(graph, axis=0)
        q25 = np.nanquantile(graph, 0.25, axis=0)
        q75 = np.nanquantile(graph, 0.75, axis=0)
        iqr = np.where((q75 - q25) > 0, q75 - q25, 1.0)
        y = np.asarray(labels, dtype=np.int64)
        n = len(y)
        n1 = max(1, int(y.sum()))
        n0 = max(1, n - n1)
        return cls(
            gap_edges=[float(value) for value in edges],
            graph_median=median.astype(float).tolist(),
            graph_iqr=iqr.astype(float).tolist(),
            positive_weight=float(n / (2 * n1)),
            negative_weight=float(n / (2 * n0)),
            fitted_fold=int(fold),
        )

    def transform_gaps(self, gap_values: np.ndarray) -> np.ndarray:
        gaps = np.log1p(np.clip(np.asarray(gap_values, dtype=np.float64), 0, None))
        return np.digitize(gaps, np.asarray(self.gap_edges), right=False).astype(np.int64)

    def transform_graph(self, values: np.ndarray) -> np.ndarray:
        array = np.asarray(values, dtype=np.float64)
        median = np.asarray(self.graph_median)
        iqr = np.asarray(self.graph_iqr)
        array = np.where(np.isnan(array), median, array)
        return ((array - median) / iqr).astype(np.float32)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict) -> "FoldPreprocessor":
        return cls(**payload)


def fit_preprocessor_from_dataset(
    dataset_dir,
    *,
    include_blocks: set[int],
    fold: int,
    gap_bins: int = 16,
    end_timestamp_at_most: int | None = None,
    sample_fraction: float = 1.0,
    sample_seed: int = 0,
) -> FoldPreprocessor:
    gap_chunks: list[np.ndarray] = []
    graph_chunks: list[np.ndarray] = []
    label_chunks: list[np.ndarray] = []
    gap_buffer: list[float] = []
    graph_buffer: list[list[float]] = []
    label_buffer: list[int] = []

    def flush() -> None:
        if not label_buffer:
            return
        gap_chunks.append(np.asarray(gap_buffer, dtype=np.float64))
        graph_chunks.append(np.asarray(graph_buffer, dtype=np.float64))
        label_chunks.append(np.asarray(label_buffer, dtype=np.int8))
        gap_buffer.clear()
        graph_buffer.clear()
        label_buffer.clear()

    for row in iter_session_rows(dataset_dir):
        if int(row["block"]) not in include_blocks:
            continue
        if end_timestamp_at_most is not None and int(row["end_timestamp"]) > end_timestamp_at_most:
            continue
        if not deterministic_include(str(row["entity_id"]), sample_fraction, sample_seed):
            continue
        gap_buffer.extend(row["gap_seconds"])
        graph_buffer.append(row["graph_features"])
        label_buffer.append(int(row["label"]))
        if len(label_buffer) >= 100_000:
            flush()
    flush()
    if not label_chunks:
        raise ValueError("No model-fitting rows were found for preprocessor fitting")
    return FoldPreprocessor.fit(
        gap_values=np.concatenate(gap_chunks),
        graph_features=np.concatenate(graph_chunks),
        labels=np.concatenate(label_chunks),
        fold=fold,
        gap_bins=gap_bins,
    )
