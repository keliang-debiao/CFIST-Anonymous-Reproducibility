from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

from .constants import GRAPH_FEATURE_NAMES, RELATION_FEATURE_NAMES, STAGE_TO_ID
from .schema import RawEvent


@dataclass
class SessionExample:
    source: str
    entity_id: str
    group_id: str
    start_timestamp: int
    end_timestamp: int
    label: int
    next_stage: int
    full_length: int
    prefix_length: int
    stage_ids: list[int]
    item_codes: list[int]
    gap_seconds: list[float]
    elapsed_seconds: list[float]
    relations: list[list[float]]
    graph_features: list[float]
    adjacent_graph_features: list[float]
    block: int = -1

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def midpoint_prefix_length(length: int, observation_ratio: float = 0.5) -> int:
    if length < 1:
        raise ValueError("Session length must be positive")
    return max(1, math.floor(observation_ratio * length))


def _local_item_codes(events: list[RawEvent]) -> list[int]:
    lookup: dict[str, int] = {}
    codes: list[int] = []
    for event in events:
        if event.item_id not in lookup:
            lookup[event.item_id] = len(lookup)
        codes.append(lookup[event.item_id])
    return codes


def _event_relations(events: list[RawEvent], prefix_length: int) -> tuple[list[list[float]], list[float], list[float]]:
    counts: dict[str, int] = {}
    last_time: dict[str, int] = {}
    unique_items: set[str] = set()
    relations: list[list[float]] = []
    gaps: list[float] = []
    elapsed: list[float] = []
    clicks = 0
    carts = 0
    start = events[0].timestamp

    for position, event in enumerate(events, start=1):
        previous_count = counts.get(event.item_id, 0)
        first_occurrence = float(previous_count == 0)
        same_previous = float(position > 1 and event.item_id == events[position - 2].item_id)
        gap = 0.0 if position == 1 else float(max(0, event.timestamp - events[position - 2].timestamp))
        since_item = 0.0 if previous_count == 0 else float(max(0, event.timestamp - last_time[event.item_id]))
        if event.stage == "click":
            clicks += 1
        elif event.stage == "cart":
            carts += 1
        counts[event.item_id] = previous_count + 1
        last_time[event.item_id] = event.timestamp
        unique_items.add(event.item_id)
        novelty = len(unique_items) / position
        repeat_ratio = (position - len(unique_items)) / position
        relations.append(
            [
                first_occurrence,
                same_previous,
                math.log1p(previous_count),
                math.log1p(since_item),
                math.log1p(clicks),
                math.log1p(carts),
                math.log1p(len(unique_items)),
                novelty,
                repeat_ratio,
                position / prefix_length,
            ]
        )
        gaps.append(gap)
        elapsed.append(float(max(0, event.timestamp - start)))

    assert all(len(row) == len(RELATION_FEATURE_NAMES) for row in relations)
    return relations, gaps, elapsed


def _graph_features(events: list[RawEvent], gaps: list[float]) -> list[float]:
    item_ids = [event.item_id for event in events]
    stage_ids = [event.stage for event in events]
    unique_count = len(set(item_ids))
    prefix_length = len(events)
    first_cart = next((idx for idx, stage in enumerate(stage_ids) if stage == "cart"), None)
    post_cart_clicks = 0
    if first_cart is not None:
        post_cart_clicks = sum(stage == "click" for stage in stage_ids[first_cart + 1 :])
    noninitial_gaps = gaps[1:] if len(gaps) > 1 else [0.0]
    values = [
        float(prefix_length),
        float(unique_count),
        float((prefix_length - unique_count) / prefix_length),
        float(sum(stage == "click" for stage in stage_ids)),
        float(sum(stage == "cart" for stage in stage_ids)),
        float(post_cart_clicks),
        float(np.mean(noninitial_gaps)),
        float(gaps[-1]),
        float(max(0, events[-1].timestamp - events[0].timestamp)),
    ]
    assert len(values) == len(GRAPH_FEATURE_NAMES)
    return values


def construct_example(
    *,
    source: str,
    entity_id: str,
    group_id: str,
    events: list[RawEvent],
    observation_ratio: float = 0.5,
    max_prefix_length: int = 68,
) -> tuple[SessionExample | None, str]:
    if len(events) < 2:
        return None, "length_below_two"
    events = sorted(events, key=lambda row: (row.timestamp, row.item_id, row.stage))
    prefix_length = midpoint_prefix_length(len(events), observation_ratio)
    full_prefix = events[:prefix_length]
    suffix = events[prefix_length:]
    if any(event.stage == "order" for event in full_prefix):
        return None, "order_in_prefix"
    label = int(any(event.stage == "order" for event in suffix))
    next_stage = STAGE_TO_ID[suffix[0].stage] if suffix else -1

    relations, gaps, elapsed = _event_relations(full_prefix, prefix_length)
    graph_features = _graph_features(full_prefix, gaps)
    adjacent_graph_features = (
        _graph_features(full_prefix[:-1], gaps[:-1]) if len(full_prefix) > 1 else list(graph_features)
    )
    item_codes = _local_item_codes(full_prefix)
    stage_ids = [STAGE_TO_ID[event.stage] for event in full_prefix]

    start_index = max(0, prefix_length - max_prefix_length)
    example = SessionExample(
        source=source,
        entity_id=str(entity_id),
        group_id=str(group_id),
        start_timestamp=events[0].timestamp,
        end_timestamp=events[-1].timestamp,
        label=label,
        next_stage=next_stage,
        full_length=len(events),
        prefix_length=prefix_length,
        stage_ids=stage_ids[start_index:],
        item_codes=item_codes[start_index:],
        gap_seconds=gaps[start_index:],
        elapsed_seconds=elapsed[start_index:],
        relations=relations[start_index:],
        graph_features=graph_features,
        adjacent_graph_features=adjacent_graph_features,
    )
    return example, "eligible"


def adjacent_prefix(example: SessionExample) -> SessionExample | None:
    if len(example.stage_ids) <= 1 or example.prefix_length <= 1:
        return None
    shorter = SessionExample(**example.to_dict())
    shorter.prefix_length -= 1
    shorter.stage_ids = shorter.stage_ids[:-1]
    shorter.item_codes = shorter.item_codes[:-1]
    shorter.gap_seconds = shorter.gap_seconds[:-1]
    shorter.elapsed_seconds = shorter.elapsed_seconds[:-1]
    shorter.relations = shorter.relations[:-1]
    shorter.graph_features = list(shorter.adjacent_graph_features)
    shorter.adjacent_graph_features = list(shorter.adjacent_graph_features)
    scale = example.prefix_length / max(1, shorter.prefix_length)
    for relation in shorter.relations:
        relation[-1] = min(1.0, relation[-1] * scale)
    return shorter
