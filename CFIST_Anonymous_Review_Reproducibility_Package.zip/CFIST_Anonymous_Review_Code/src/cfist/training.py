from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np

from .dataset import adjacent_batch
from .losses import GroupDRO, complete_objective
from .metrics import binary_metrics


@dataclass
class EpochRecord:
    epoch: int
    learning_rate: float
    training_loss: float
    development_auprc: float
    development_auroc: float
    development_brier: float
    seconds: float


def move_batch(batch: dict, device):
    import torch

    return {key: value.to(device) if torch.is_tensor(value) else value for key, value in batch.items()}


def predict(model, loader, device) -> dict[str, np.ndarray]:
    import torch

    model.eval()
    collected = {
        "entity_id": [], "group_id": [], "label": [], "logit": [], "probability": [],
        "error_proxy": [], "representation": [], "fusion_weight": [], "prefix_length": [],
        "environment": [],
    }
    with torch.inference_mode():
        for batch in loader:
            ids = batch["entity_id"]
            groups = batch["group_id"]
            batch = move_batch(batch, device)
            output = model(batch)
            collected["entity_id"].extend(ids)
            collected["group_id"].extend(groups)
            collected["label"].append(batch["label"].detach().cpu().numpy())
            collected["logit"].append(output.purchase_logit.detach().cpu().numpy())
            collected["probability"].append(output.probability.detach().cpu().numpy())
            collected["error_proxy"].append(output.error_proxy.detach().cpu().numpy())
            collected["representation"].append(output.representation.detach().cpu().numpy())
            collected["fusion_weight"].append(output.fusion_weight.detach().cpu().numpy())
            collected["prefix_length"].append(batch["prefix_length"].detach().cpu().numpy())
            collected["environment"].append(batch["environment"].detach().cpu().numpy())
    output = {}
    for key, values in collected.items():
        if key in {"entity_id", "group_id"}:
            output[key] = np.asarray(values, dtype=object)
        else:
            output[key] = np.concatenate(values, axis=0)
    return output


def fit_network(
    *,
    model,
    training_loader,
    development_loader,
    config: dict,
    preprocessor,
    fold: int,
    seed: int,
    output_dir: str | Path,
):
    import torch

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    optimization = config["optimization"]
    device_request = config["project"].get("device", "auto")
    if device_request == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(device_request)
    model.to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(optimization["learning_rate"]),
        weight_decay=float(optimization["weight_decay"]),
    )
    epochs = int(optimization["epochs"])
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(1, epochs))
    scaler = torch.amp.GradScaler("cuda", enabled=bool(optimization["automatic_mixed_precision"]) and device.type == "cuda")
    group_dro = None
    if bool(optimization.get("group_dro_enabled", True)):
        group_dro = GroupDRO(
            environments=int(config["data"]["otto_blocks"]),
            eta=float(optimization["group_dro_eta"]),
            regularization=float(optimization["group_dro_regularization"]),
            minimum_samples=int(optimization["minimum_environment_samples"]),
        ).to(device)

    best_auprc = -np.inf
    best_epoch = 0
    patience = 0
    history: list[EpochRecord] = []
    checkpoint_path = output_dir / f"fold_{fold}_seed_{seed}.pt"

    for epoch in range(1, epochs + 1):
        start = time.perf_counter()
        model.train()
        if group_dro is not None:
            group_dro.train()
        running = []
        for batch in training_loader:
            batch = move_batch(batch, device)
            short_batch, adjacent_valid = adjacent_batch(batch)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, enabled=scaler.is_enabled()):
                output = model(batch)
                short_output = model(short_batch)
                loss, _ = complete_objective(
                    output=output,
                    short_output=short_output,
                    batch=batch,
                    adjacent_valid=adjacent_valid,
                    group_dro=group_dro,
                    positive_weight=preprocessor.positive_weight,
                    negative_weight=preprocessor.negative_weight,
                    lambda_stage=float(optimization["lambda_stage"]),
                    lambda_prefix=float(optimization["lambda_prefix"]),
                    lambda_uncertainty=float(optimization["lambda_uncertainty"]),
                )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), float(optimization["gradient_clip_norm"]))
            scaler.step(optimizer)
            scaler.update()
            running.append(float(loss.detach().cpu()))
        scheduler.step()

        development = predict(model, development_loader, device)
        metrics = binary_metrics(development["label"], development["probability"])
        record = EpochRecord(
            epoch=epoch,
            learning_rate=float(optimizer.param_groups[0]["lr"]),
            training_loss=float(np.mean(running)),
            development_auprc=metrics["auprc"],
            development_auroc=metrics["auroc"],
            development_brier=metrics["brier"],
            seconds=time.perf_counter() - start,
        )
        history.append(record)
        if metrics["auprc"] > best_auprc:
            best_auprc = metrics["auprc"]
            best_epoch = epoch
            patience = 0
            torch.save(
                {
                    "model_state": model.state_dict(),
                    "group_dro_state": None if group_dro is None else group_dro.state_dict(),
                    "fold": fold,
                    "seed": seed,
                    "best_epoch": epoch,
                    "configuration": config,
                    "preprocessor": preprocessor.to_dict(),
                },
                checkpoint_path,
            )
        else:
            patience += 1
            if patience >= int(optimization["early_stopping_patience"]):
                break

    with (output_dir / f"fold_{fold}_seed_{seed}_history.json").open("w", encoding="utf-8") as handle:
        json.dump([asdict(record) for record in history], handle, indent=2)
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model_state"])
    return model, {"best_epoch": best_epoch, "best_development_auprc": best_auprc, "history": history}
