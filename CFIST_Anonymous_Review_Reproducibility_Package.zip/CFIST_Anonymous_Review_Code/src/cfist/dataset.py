from __future__ import annotations

import random
from pathlib import Path
from typing import Iterable, Iterator

import numpy as np

from .preprocessing import FoldPreprocessor
from .sampling import deterministic_include
from .storage import iter_session_rows


def _require_torch():
    try:
        import torch
        from torch.utils.data import IterableDataset
    except ImportError as exc:
        raise RuntimeError("PyTorch is required for neural model execution") from exc
    return torch, IterableDataset


class ParquetSessionIterable:
    """Factory for a worker-aware iterable PyTorch dataset."""

    @staticmethod
    def create(
        dataset_dir: str | Path,
        *,
        include_blocks: set[int] | None,
        preprocessor: FoldPreprocessor,
        shuffle_buffer: int = 8192,
        seed: int = 0,
        end_timestamp_at_most: int | None = None,
        end_timestamp_after: int | None = None,
        sample_fraction: float = 1.0,
        sample_seed: int = 0,
    ):
        torch, IterableDataset = _require_torch()

        class _Dataset(IterableDataset):
            def __iter__(self) -> Iterator[dict]:
                worker = torch.utils.data.get_worker_info()
                worker_id = 0 if worker is None else worker.id
                worker_count = 1 if worker is None else worker.num_workers
                rng = random.Random(seed + worker_id)
                buffer: list[dict] = []
                for row_index, row in enumerate(iter_session_rows(dataset_dir)):
                    if row_index % worker_count != worker_id:
                        continue
                    if include_blocks is not None and int(row.get("block", -1)) not in include_blocks:
                        continue
                    if end_timestamp_at_most is not None and int(row["end_timestamp"]) > end_timestamp_at_most:
                        continue
                    if end_timestamp_after is not None and int(row["end_timestamp"]) <= end_timestamp_after:
                        continue
                    if not deterministic_include(str(row["entity_id"]), sample_fraction, sample_seed):
                        continue
                    row["gap_bins"] = preprocessor.transform_gaps(np.asarray(row["gap_seconds"])).tolist()
                    row["graph_features"] = preprocessor.transform_graph(
                        np.asarray(row["graph_features"])
                    ).tolist()
                    row["adjacent_graph_features"] = preprocessor.transform_graph(
                        np.asarray(row["adjacent_graph_features"])
                    ).tolist()
                    if shuffle_buffer <= 1:
                        yield row
                        continue
                    buffer.append(row)
                    if len(buffer) >= shuffle_buffer:
                        pick = rng.randrange(len(buffer))
                        yield buffer.pop(pick)
                while buffer:
                    yield buffer.pop(rng.randrange(len(buffer)))

        return _Dataset()


def collate_sessions(rows: list[dict], max_prefix_length: int = 68) -> dict:
    torch, _ = _require_torch()
    batch_size = len(rows)
    lengths = [min(len(row["stage_ids"]), max_prefix_length) for row in rows]
    width = max(lengths)
    relation_dim = len(rows[0]["relations"][0])
    graph_dim = len(rows[0]["graph_features"])

    stage = torch.zeros((batch_size, width), dtype=torch.long)
    item = torch.full((batch_size, width), -1, dtype=torch.long)
    gap_bins = torch.zeros((batch_size, width), dtype=torch.long)
    elapsed = torch.zeros((batch_size, width), dtype=torch.float32)
    gap_seconds = torch.zeros((batch_size, width), dtype=torch.float32)
    relations = torch.zeros((batch_size, width, relation_dim), dtype=torch.float32)
    mask = torch.zeros((batch_size, width), dtype=torch.bool)
    graph = torch.zeros((batch_size, graph_dim), dtype=torch.float32)
    adjacent_graph = torch.zeros((batch_size, graph_dim), dtype=torch.float32)

    for batch_index, row in enumerate(rows):
        length = lengths[batch_index]
        source_slice = slice(len(row["stage_ids"]) - length, None)
        stage[batch_index, :length] = torch.as_tensor(row["stage_ids"][source_slice])
        item[batch_index, :length] = torch.as_tensor(row["item_codes"][source_slice])
        gap_bins[batch_index, :length] = torch.as_tensor(row["gap_bins"][source_slice])
        elapsed[batch_index, :length] = torch.as_tensor(row["elapsed_seconds"][source_slice])
        gap_seconds[batch_index, :length] = torch.as_tensor(row["gap_seconds"][source_slice])
        relations[batch_index, :length] = torch.as_tensor(row["relations"][source_slice])
        mask[batch_index, :length] = True
        graph[batch_index] = torch.as_tensor(row["graph_features"])
        adjacent_graph[batch_index] = torch.as_tensor(row["adjacent_graph_features"])

    return {
        "stage_ids": stage,
        "item_codes": item,
        "gap_bins": gap_bins,
        "elapsed_seconds": elapsed,
        "gap_seconds": gap_seconds,
        "relations": relations,
        "attention_mask": mask,
        "graph_features": graph,
        "adjacent_graph_features": adjacent_graph,
        "prefix_length": torch.as_tensor([row["prefix_length"] for row in rows], dtype=torch.float32),
        "label": torch.as_tensor([row["label"] for row in rows], dtype=torch.float32),
        "next_stage": torch.as_tensor([row["next_stage"] for row in rows], dtype=torch.long),
        "environment": torch.as_tensor([row.get("block", 0) for row in rows], dtype=torch.long),
        "entity_id": [str(row["entity_id"]) for row in rows],
        "group_id": [str(row["group_id"]) for row in rows],
    }


def adjacent_batch(batch: dict) -> tuple[dict, object]:
    torch, _ = _require_torch()
    lengths = batch["attention_mask"].sum(dim=1)
    valid = lengths > 1
    short = {}
    for key, value in batch.items():
        if not torch.is_tensor(value):
            short[key] = value
        else:
            short[key] = value.clone()
    for idx in torch.nonzero(valid, as_tuple=False).flatten().tolist():
        last = int(lengths[idx].item() - 1)
        short["attention_mask"][idx, last] = False
        short["stage_ids"][idx, last] = 0
        short["item_codes"][idx, last] = -1
        short["gap_bins"][idx, last] = 0
        short["elapsed_seconds"][idx, last] = 0.0
        short["gap_seconds"][idx, last] = 0.0
        short["relations"][idx, last] = 0.0
        short["prefix_length"][idx] = torch.clamp(short["prefix_length"][idx] - 1, min=1)
        original_length = batch["prefix_length"][idx].clamp_min(2.0)
        short_length = short["prefix_length"][idx].clamp_min(1.0)
        short["relations"][idx, :, -1] = torch.clamp(
            short["relations"][idx, :, -1] * (original_length / short_length), max=1.0
        )
        short["graph_features"][idx] = batch["adjacent_graph_features"][idx]
    return short, valid
