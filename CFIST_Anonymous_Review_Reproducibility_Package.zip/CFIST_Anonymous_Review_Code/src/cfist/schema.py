from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any

from .constants import SOURCE_STAGE_MAP


@dataclass(frozen=True)
class RawEvent:
    item_id: str
    stage: str
    timestamp: int


def harmonize_stage(source: str, raw_stage: str) -> str:
    source_key = source.strip().lower()
    stage_key = str(raw_stage).strip().lower()
    try:
        return SOURCE_STAGE_MAP[source_key][stage_key]
    except KeyError as exc:
        raise ValueError(f"Unsupported event stage {raw_stage!r} for source {source!r}") from exc


def normalize_events(source: str, events: Iterable[dict[str, Any]]) -> list[RawEvent]:
    normalized: list[RawEvent] = []
    for event in events:
        if source == "otto":
            item_id = event["aid"]
            raw_stage = event["type"]
            timestamp = int(event["ts"]) // 1000
        elif source == "retailrocket":
            item_id = event["itemid"]
            raw_stage = event["event"]
            timestamp = int(event["timestamp"]) // 1000
        else:
            raise ValueError(f"Unknown source: {source}")
        normalized.append(
            RawEvent(
                item_id=str(item_id),
                stage=harmonize_stage(source, str(raw_stage)),
                timestamp=int(timestamp),
            )
        )
    normalized.sort(key=lambda row: (row.timestamp, row.item_id, row.stage))
    return normalized


def audit_event_order(events: list[RawEvent]) -> dict[str, int]:
    reverse_steps = sum(a.timestamp > b.timestamp for a, b in zip(events, events[1:]))
    exact_duplicates = len(events) - len({(e.item_id, e.stage, e.timestamp) for e in events})
    return {
        "events": len(events),
        "reverse_time_steps": reverse_steps,
        "exact_duplicate_events": exact_duplicates,
    }
