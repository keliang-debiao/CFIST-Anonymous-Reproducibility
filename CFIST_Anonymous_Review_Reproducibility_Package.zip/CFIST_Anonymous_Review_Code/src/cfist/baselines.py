from __future__ import annotations

import math

import torch
from torch import nn


class PrefixMLP(nn.Module):
    def __init__(self, feature_dim: int = 9, hidden: int = 128, dropout: float = 0.1):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(feature_dim, hidden), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(hidden, hidden), nn.GELU(), nn.Dropout(dropout), nn.Linear(hidden, 1),
        )

    def forward(self, batch):
        return self.network(batch["graph_features"]).squeeze(-1)


class FTTransformerBaseline(nn.Module):
    def __init__(self, features: int = 9, dim: int = 128, layers: int = 3, heads: int = 4, dropout: float = 0.1):
        super().__init__()
        self.value_projection = nn.Linear(1, dim)
        self.feature_embedding = nn.Embedding(features + 1, dim)
        layer = nn.TransformerEncoderLayer(dim, heads, 4 * dim, dropout, batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(layer, layers)
        self.head = nn.Linear(dim, 1)
        self.features = features

    def forward(self, batch):
        values = batch["graph_features"].unsqueeze(-1)
        feature_ids = torch.arange(self.features, device=values.device)
        tokens = self.value_projection(values) + self.feature_embedding(feature_ids)[None]
        cls = self.feature_embedding.weight[self.features][None, None].expand(values.shape[0], 1, -1)
        encoded = self.encoder(torch.cat([cls, tokens], dim=1))
        return self.head(encoded[:, 0]).squeeze(-1)


class SequenceGRU(nn.Module):
    def __init__(self, dim: int = 128, gap_bins: int = 16, relation_dim: int = 10, layers: int = 2, dropout: float = 0.1):
        super().__init__()
        self.stage = nn.Embedding(3, dim)
        self.gap = nn.Embedding(gap_bins, dim)
        self.relation = nn.Linear(relation_dim, dim, bias=False)
        self.gru = nn.GRU(dim, dim, layers, batch_first=True, dropout=dropout if layers > 1 else 0)
        self.head = nn.Linear(dim, 1)

    def forward(self, batch):
        token = self.stage(batch["stage_ids"]) + self.gap(batch["gap_bins"]) + self.relation(batch["relations"])
        encoded, _ = self.gru(token)
        last = batch["attention_mask"].sum(dim=1).sub(1).clamp_min(0)
        pooled = encoded[torch.arange(encoded.shape[0], device=encoded.device), last]
        return self.head(pooled).squeeze(-1)


class SequenceTransformer(nn.Module):
    def __init__(self, dim: int = 128, gap_bins: int = 16, relation_dim: int = 10, layers: int = 3, heads: int = 4, dropout: float = 0.1):
        super().__init__()
        self.stage = nn.Embedding(3, dim)
        self.gap = nn.Embedding(gap_bins, dim)
        self.relation = nn.Linear(relation_dim, dim, bias=False)
        layer = nn.TransformerEncoderLayer(dim, heads, 4 * dim, dropout, batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(layer, layers)
        self.head = nn.Linear(dim, 1)

    def encode(self, batch):
        token = self.stage(batch["stage_ids"]) + self.gap(batch["gap_bins"]) + self.relation(batch["relations"])
        length = token.shape[1]
        causal = torch.triu(torch.ones(length, length, device=token.device, dtype=torch.bool), diagonal=1)
        encoded = self.encoder(token, mask=causal, src_key_padding_mask=~batch["attention_mask"])
        last = batch["attention_mask"].sum(dim=1).sub(1).clamp_min(0)
        pooled = encoded[torch.arange(encoded.shape[0], device=encoded.device), last]
        return pooled

    def forward(self, batch):
        return self.head(self.encode(batch)).squeeze(-1)


class SessionGraphBaseline(nn.Module):
    def __init__(self, dim: int = 128, gap_bins: int = 16, relation_dim: int = 10, steps: int = 2):
        super().__init__()
        self.stage = nn.Embedding(3, dim)
        self.gap = nn.Embedding(gap_bins, dim)
        self.relation = nn.Linear(relation_dim, dim, bias=False)
        self.update = nn.GRUCell(dim, dim)
        self.steps = steps
        self.head = nn.Linear(dim, 1)

    def forward(self, batch):
        state = self.stage(batch["stage_ids"]) + self.gap(batch["gap_bins"]) + self.relation(batch["relations"])
        valid = batch["attention_mask"].to(state.dtype)
        item = batch["item_codes"]
        adjacency = (item[:, :, None] == item[:, None, :]) & (item[:, :, None] >= 0)
        length = state.shape[1]
        sequential = torch.eye(length, device=state.device, dtype=torch.bool)
        sequential[1:, :-1] |= torch.eye(length - 1, device=state.device, dtype=torch.bool)
        adjacency = adjacency | sequential[None]
        adjacency = adjacency & batch["attention_mask"][:, :, None] & batch["attention_mask"][:, None, :]
        weight = adjacency.to(state.dtype)
        weight = weight / weight.sum(dim=-1, keepdim=True).clamp_min(1.0)
        for _ in range(self.steps):
            message = torch.matmul(weight, state)
            state = self.update(message.reshape(-1, state.shape[-1]), state.reshape(-1, state.shape[-1])).reshape_as(state)
        pooled = (state * valid.unsqueeze(-1)).sum(dim=1) / valid.sum(dim=1, keepdim=True).clamp_min(1.0)
        return self.head(pooled).squeeze(-1)


class PrefixSequenceFusionBaseline(nn.Module):
    def __init__(self, dim: int = 128, gap_bins: int = 16, relation_dim: int = 10, heads: int = 4, layers: int = 3):
        super().__init__()
        self.sequence = SequenceTransformer(dim, gap_bins, relation_dim, layers, heads)
        self.statistics = nn.Sequential(nn.Linear(9, dim), nn.GELU(), nn.Linear(dim, dim))
        self.head = nn.Sequential(nn.Linear(2 * dim, dim), nn.GELU(), nn.Linear(dim, 1))

    def forward(self, batch):
        seq_scalar = self.sequence.encode(batch)
        stats = self.statistics(batch["graph_features"])
        return self.head(torch.cat([stats, seq_scalar], dim=-1)).squeeze(-1)


def build_neural_baseline(name: str, config: dict) -> nn.Module:
    model = config["model"]
    data = config["data"]
    dim = int(model["representation_dim"])
    gap_bins = int(data["gap_bins"])
    relation_dim = int(model["relation_features"])
    normalized = name.lower()
    if normalized == "mlp":
        return PrefixMLP(hidden=dim)
    if normalized == "ft-transformer":
        return FTTransformerBaseline(dim=dim, heads=int(model["attention_heads"]))
    if normalized == "gru4rec":
        return SequenceGRU(dim=dim, gap_bins=gap_bins, relation_dim=relation_dim)
    if normalized in {"sasrec", "tron-backbone"}:
        return SequenceTransformer(dim=dim, gap_bins=gap_bins, relation_dim=relation_dim, heads=int(model["attention_heads"]))
    if normalized == "sr-gnn":
        return SessionGraphBaseline(dim=dim, gap_bins=gap_bins, relation_dim=relation_dim)
    if normalized == "pte-gt-backbone":
        return PrefixSequenceFusionBaseline(dim=dim, gap_bins=gap_bins, relation_dim=relation_dim, heads=int(model["attention_heads"]))
    raise ValueError(f"Unsupported built-in neural baseline: {name}")
