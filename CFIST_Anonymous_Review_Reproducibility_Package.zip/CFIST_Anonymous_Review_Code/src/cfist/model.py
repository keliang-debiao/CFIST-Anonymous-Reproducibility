from __future__ import annotations

import math
from dataclasses import dataclass

import torch
from torch import nn
from torch.nn import functional as F


@dataclass
class CFISTOutput:
    purchase_logit: torch.Tensor
    probability: torch.Tensor
    error_proxy: torch.Tensor
    next_stage_logits: torch.Tensor
    representation: torch.Tensor
    sequence_representation: torch.Tensor
    graph_representation: torch.Tensor
    fusion_weight: torch.Tensor


class RelationalEventTokenizer(nn.Module):
    def __init__(self, dim: int, max_length: int, gap_bins: int, relation_dim: int, dropout: float, use_relations: bool = True):
        super().__init__()
        self.stage_embedding = nn.Embedding(3, dim)
        self.position_embedding = nn.Embedding(max_length, dim)
        self.gap_embedding = nn.Embedding(gap_bins, dim)
        self.relation_projection = nn.Linear(relation_dim, dim, bias=False)
        self.normalization = nn.LayerNorm(dim)
        self.dropout = nn.Dropout(dropout)
        self.use_relations = use_relations

    def forward(self, stage_ids, gap_bins, relations):
        batch, length = stage_ids.shape
        positions = torch.arange(length, device=stage_ids.device).expand(batch, length)
        token = (
            self.stage_embedding(stage_ids)
            + self.position_embedding(positions)
            + self.gap_embedding(gap_bins)
            + (self.relation_projection(relations) if self.use_relations else 0.0)
        )
        return self.dropout(self.normalization(token))


class FunnelBiasedLocalAttention(nn.Module):
    def __init__(self, dim: int, heads: int, gap_bins: int, window: int, dropout: float, use_funnel_bias: bool = True):
        super().__init__()
        if dim % heads:
            raise ValueError("representation dimension must be divisible by attention heads")
        self.dim = dim
        self.heads = heads
        self.head_dim = dim // heads
        self.window = window
        self.qkv = nn.Linear(dim, 3 * dim)
        self.output = nn.Linear(dim, dim)
        self.stage_bias = nn.Embedding(9, heads)
        self.gap_bias = nn.Embedding(gap_bins, heads)
        self.pair_bias = nn.Linear(3, heads, bias=False)
        self.dropout = nn.Dropout(dropout)
        self.use_funnel_bias = use_funnel_bias

    def forward(self, x, stage_ids, item_codes, gap_bins, attention_mask):
        batch, length, _ = x.shape
        qkv = self.qkv(x).reshape(batch, length, 3, self.heads, self.head_dim)
        q, k, v = qkv.unbind(dim=2)
        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)
        scores = torch.matmul(q, k.transpose(-1, -2)) / math.sqrt(self.head_dim)

        key_stage = stage_ids[:, None, :, None]
        query_stage = stage_ids[:, :, None, None]
        stage_index = (key_stage * 3 + query_stage).squeeze(-1)
        if self.use_funnel_bias:
            scores = scores + self.stage_bias(stage_index).permute(0, 3, 1, 2)

        pair_gap = torch.abs(gap_bins[:, :, None] - gap_bins[:, None, :])
        pair_gap = torch.clamp(pair_gap, max=self.gap_bias.num_embeddings - 1)
        if self.use_funnel_bias:
            scores = scores + self.gap_bias(pair_gap).permute(0, 3, 1, 2)

        query_pos = torch.arange(length, device=x.device)[:, None]
        key_pos = torch.arange(length, device=x.device)[None, :]
        relative = (query_pos - key_pos).to(x.dtype) / max(1, length - 1)
        same_item = (item_codes[:, :, None] == item_codes[:, None, :]) & (item_codes[:, :, None] >= 0)
        revisit = same_item & (key_pos[None, :, :] < query_pos[None, :, :])
        pair_features = torch.stack(
            [
                same_item.to(x.dtype),
                relative.expand(batch, -1, -1),
                revisit.to(x.dtype),
            ],
            dim=-1,
        )
        if self.use_funnel_bias:
            scores = scores + self.pair_bias(pair_features).permute(0, 3, 1, 2)

        causal_local = (key_pos <= query_pos) & ((query_pos - key_pos) <= self.window)
        valid = causal_local[None, None, :, :] & attention_mask[:, None, None, :]
        scores = scores.masked_fill(~valid, torch.finfo(scores.dtype).min)
        weights = torch.softmax(scores, dim=-1)
        weights = torch.where(attention_mask[:, None, :, None], weights, torch.zeros_like(weights))
        context = torch.matmul(self.dropout(weights), v)
        context = context.transpose(1, 2).reshape(batch, length, self.dim)
        return self.output(context)


class FunnelEncoderLayer(nn.Module):
    def __init__(self, dim: int, heads: int, gap_bins: int, window: int, dropout: float, ff_mult: int, use_funnel_bias: bool = True):
        super().__init__()
        self.attention = FunnelBiasedLocalAttention(dim, heads, gap_bins, window, dropout, use_funnel_bias)
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(
            nn.Linear(dim, ff_mult * dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(ff_mult * dim, dim),
            nn.Dropout(dropout),
        )

    def forward(self, x, stage_ids, item_codes, gap_bins, attention_mask):
        x = self.norm1(x + self.attention(x, stage_ids, item_codes, gap_bins, attention_mask))
        x = self.norm2(x + self.ffn(x))
        return x * attention_mask.unsqueeze(-1)


class SequenceEncoder(nn.Module):
    def __init__(self, dim, layers, heads, gap_bins, window, dropout, ff_mult, use_funnel_bias=True):
        super().__init__()
        self.layers = nn.ModuleList(
            [FunnelEncoderLayer(dim, heads, gap_bins, window, dropout, ff_mult, use_funnel_bias) for _ in range(layers)]
        )
        self.pool_query = nn.Parameter(torch.zeros(dim))
        nn.init.normal_(self.pool_query, std=0.02)

    def forward(self, x, stage_ids, item_codes, gap_bins, attention_mask):
        for layer in self.layers:
            x = layer(x, stage_ids, item_codes, gap_bins, attention_mask)
        score = torch.einsum("bld,d->bl", x, self.pool_query) / math.sqrt(x.shape[-1])
        score = score.masked_fill(~attention_mask, torch.finfo(score.dtype).min)
        weights = torch.softmax(score, dim=1)
        return torch.einsum("bl,bld->bd", weights, x)


def default_graph_support() -> torch.Tensor:
    support = torch.eye(9, dtype=torch.float32)
    edges = [
        (1, 0), (2, 0), (3, 0), (4, 0), (2, 1),
        (4, 3), (5, 4), (8, 6), (8, 7), (6, 0), (7, 0),
    ]
    for target, source in edges:
        support[target, source] = 1.0
    return support


class PartialOrderGraphEncoder(nn.Module):
    def __init__(self, nodes: int, dim: int, layers: int, dropout: float):
        super().__init__()
        if nodes != 9:
            raise ValueError("CFIST uses the nine declared prefix-statistic nodes")
        self.nodes = nodes
        self.scalar_projection = nn.Linear(1, dim)
        self.node_embedding = nn.Embedding(nodes, dim)
        self.raw_edge_weight = nn.Parameter(torch.zeros(nodes, nodes))
        self.register_buffer("support", default_graph_support())
        self.transforms = nn.ModuleList([nn.Linear(dim, dim) for _ in range(layers)])
        self.norms = nn.ModuleList([nn.LayerNorm(dim) for _ in range(layers)])
        self.dropout = nn.Dropout(dropout)

    def forward(self, graph_features):
        batch = graph_features.shape[0]
        nodes = torch.arange(self.nodes, device=graph_features.device)
        state = self.scalar_projection(graph_features.unsqueeze(-1))
        state = state + self.node_embedding(nodes)[None, :, :]
        adjacency = F.softplus(self.raw_edge_weight) * self.support
        adjacency = adjacency / adjacency.sum(dim=1, keepdim=True).clamp_min(1e-6)
        for transform, norm in zip(self.transforms, self.norms):
            propagated = torch.einsum("nm,bmd->bnd", adjacency, state)
            update = F.gelu(transform(propagated))
            state = norm(state + self.dropout(update))
        return state.mean(dim=1).reshape(batch, -1)


class CFIST(nn.Module):
    def __init__(
        self,
        *,
        dim: int = 128,
        layers: int = 4,
        heads: int = 4,
        local_window: int = 32,
        max_length: int = 68,
        gap_bins: int = 16,
        relation_dim: int = 10,
        graph_nodes: int = 9,
        graph_layers: int = 2,
        dropout: float = 0.10,
        ff_mult: int = 4,
        use_relations: bool = True,
        use_funnel_bias: bool = True,
        use_graph: bool = True,
        fixed_fusion: bool = False,
    ):
        super().__init__()
        self.tokenizer = RelationalEventTokenizer(dim, max_length, gap_bins, relation_dim, dropout, use_relations)
        self.sequence = SequenceEncoder(dim, layers, heads, gap_bins, local_window, dropout, ff_mult, use_funnel_bias)
        self.graph = PartialOrderGraphEncoder(graph_nodes, dim, graph_layers, dropout)
        self.fusion_gate = nn.Linear(2 * dim + 1, 1)
        self.purchase_head = nn.Linear(dim, 1)
        self.error_head = nn.Sequential(nn.Linear(dim, dim // 2), nn.GELU(), nn.Linear(dim // 2, 1))
        self.next_stage_head = nn.Linear(dim, 3)
        self.use_graph = use_graph
        self.fixed_fusion = fixed_fusion

    def forward(self, batch: dict) -> CFISTOutput:
        token = self.tokenizer(batch["stage_ids"], batch["gap_bins"], batch["relations"])
        sequence = self.sequence(
            token,
            batch["stage_ids"],
            batch["item_codes"],
            batch["gap_bins"],
            batch["attention_mask"],
        )
        graph = self.graph(batch["graph_features"]) if self.use_graph else torch.zeros_like(sequence)
        log_length = torch.log1p(batch["prefix_length"]).unsqueeze(-1)
        if not self.use_graph:
            alpha = torch.ones((sequence.shape[0], 1), device=sequence.device, dtype=sequence.dtype)
            representation = sequence
        else:
            alpha = torch.sigmoid(self.fusion_gate(torch.cat([sequence, graph, log_length], dim=-1)))
            if self.fixed_fusion:
                alpha = torch.full_like(alpha, 0.5)
            representation = alpha * sequence + (1.0 - alpha) * graph
        purchase_logit = self.purchase_head(representation).squeeze(-1)
        error_proxy = F.softplus(self.error_head(representation).squeeze(-1))
        return CFISTOutput(
            purchase_logit=purchase_logit,
            probability=torch.sigmoid(purchase_logit),
            error_proxy=error_proxy,
            next_stage_logits=self.next_stage_head(representation),
            representation=representation,
            sequence_representation=sequence,
            graph_representation=graph,
            fusion_weight=alpha.squeeze(-1),
        )


def build_model(config: dict) -> CFIST:
    model = config["model"]
    data = config["data"]
    ablation = config.get("ablation", {})
    return CFIST(
        dim=int(model["representation_dim"]),
        layers=int(model["encoder_layers"]),
        heads=int(model["attention_heads"]),
        local_window=int(model["local_window"]),
        max_length=int(data["max_prefix_length"]),
        gap_bins=int(data["gap_bins"]),
        relation_dim=int(model["relation_features"]),
        graph_nodes=int(model["graph_nodes"]),
        graph_layers=int(model["graph_layers"]),
        dropout=float(model["dropout"]),
        ff_mult=int(model["feedforward_multiplier"]),
        use_relations=not bool(ablation.get("remove_relational_tokenization", False)),
        use_funnel_bias=not bool(ablation.get("remove_funnel_biases", False)),
        use_graph=not bool(ablation.get("remove_feature_graph", False)),
        fixed_fusion=bool(ablation.get("fixed_fusion", False)),
    )
