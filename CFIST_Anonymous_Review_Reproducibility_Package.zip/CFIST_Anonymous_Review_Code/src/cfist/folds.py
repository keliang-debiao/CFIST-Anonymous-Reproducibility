from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class TimeBlock:
    block: int
    start_timestamp: int
    end_timestamp: int


def equal_duration_boundaries(timestamps: np.ndarray, n_blocks: int = 6) -> list[TimeBlock]:
    values = np.asarray(timestamps, dtype=np.int64)
    if values.size == 0:
        raise ValueError("At least one timestamp is required")
    if n_blocks < 2:
        raise ValueError("At least two chronological blocks are required")
    lower = int(values.min())
    upper = int(values.max())
    edges = np.linspace(lower, upper + 1, n_blocks + 1, dtype=np.int64)
    edges[-1] = upper + 1
    return [
        TimeBlock(block=i, start_timestamp=int(edges[i]), end_timestamp=int(edges[i + 1] - 1))
        for i in range(n_blocks)
    ]


def assign_blocks(timestamps: np.ndarray, boundaries: list[TimeBlock]) -> np.ndarray:
    values = np.asarray(timestamps, dtype=np.int64)
    upper_edges = np.array([block.end_timestamp for block in boundaries], dtype=np.int64)
    assigned = np.searchsorted(upper_edges, values, side="left")
    if np.any(assigned < 0) or np.any(assigned >= len(boundaries)):
        raise AssertionError("A timestamp lies outside the declared block boundaries")
    return assigned.astype(np.int8)


def rolling_outer_fold(block_ids: np.ndarray, fold: int) -> tuple[np.ndarray, np.ndarray]:
    if fold not in {1, 2, 3, 4, 5}:
        raise ValueError("Outer fold must be in 1..5")
    blocks = np.asarray(block_ids)
    train = np.flatnonzero(blocks < fold)
    validation = np.flatnonzero(blocks == fold)
    if train.size == 0 or validation.size == 0:
        raise ValueError(f"Fold {fold} has an empty partition")
    return train, validation


def terminal_development_split(
    timestamps: np.ndarray,
    historical_indices: np.ndarray,
    development_fraction: float = 0.10,
) -> tuple[np.ndarray, np.ndarray]:
    if not 0 < development_fraction < 1:
        raise ValueError("development_fraction must be in (0, 1)")
    ordered = historical_indices[np.argsort(np.asarray(timestamps)[historical_indices], kind="stable")]
    cut = max(1, int(np.floor((1.0 - development_fraction) * len(ordered))))
    fitting, development = ordered[:cut], ordered[cut:]
    if fitting.size == 0 or development.size == 0:
        raise ValueError("Model-fitting and development partitions must both be nonempty")
    if np.max(np.asarray(timestamps)[fitting]) > np.min(np.asarray(timestamps)[development]):
        raise AssertionError("Terminal development partition is not chronological")
    return fitting, development


def assert_no_group_overlap(group_ids: np.ndarray, *partitions: np.ndarray) -> None:
    groups = np.asarray(group_ids)
    seen: set[str] = set()
    for partition in partitions:
        current = set(map(str, groups[partition].tolist()))
        overlap = seen.intersection(current)
        if overlap:
            raise AssertionError(f"Group leakage detected for {len(overlap)} group identifiers")
        seen.update(current)
