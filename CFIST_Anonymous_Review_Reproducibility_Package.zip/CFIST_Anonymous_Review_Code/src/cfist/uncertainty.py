from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class RobustPrototypeSet:
    environment_ids: list[int]
    medians: list[list[float]]
    scales_squared: list[list[float]]
    epsilon: float = 1e-6

    @classmethod
    def fit(cls, representations: np.ndarray, environments: np.ndarray, epsilon: float = 1e-6):
        x = np.asarray(representations, dtype=np.float64)
        env = np.asarray(environments, dtype=np.int64)
        environment_ids: list[int] = []
        medians: list[list[float]] = []
        scales: list[list[float]] = []
        for value in sorted(np.unique(env).tolist()):
            current = x[env == value]
            if len(current) == 0:
                continue
            median = np.median(current, axis=0)
            mad = np.median(np.abs(current - median), axis=0)
            robust_scale = np.maximum(1.4826 * mad, np.sqrt(epsilon))
            environment_ids.append(int(value))
            medians.append(median.tolist())
            scales.append(np.square(robust_scale).tolist())
        return cls(environment_ids, medians, scales, epsilon)

    def distance(self, representations: np.ndarray) -> np.ndarray:
        x = np.asarray(representations, dtype=np.float64)
        distances = []
        for median, scale in zip(self.medians, self.scales_squared):
            delta = x - np.asarray(median)
            distances.append(np.sum(np.square(delta) / (np.asarray(scale) + self.epsilon), axis=1))
        if not distances:
            raise ValueError("No temporal environment prototype is available")
        return np.min(np.stack(distances, axis=1), axis=1)

    def to_dict(self) -> dict:
        return {
            "environment_ids": self.environment_ids,
            "medians": self.medians,
            "scales_squared": self.scales_squared,
            "epsilon": self.epsilon,
        }


def structural_uncertainty(error_proxy: np.ndarray, prefix_length: np.ndarray, tau: float) -> np.ndarray:
    if tau <= 0:
        raise ValueError("tau must be positive")
    return np.asarray(error_proxy, dtype=np.float64) + np.exp(-np.asarray(prefix_length) / tau)


def acceptance_threshold(uncertainty: np.ndarray, coverage: float) -> float:
    if not 0 < coverage <= 1:
        raise ValueError("coverage must be in (0, 1]")
    return float(np.quantile(np.asarray(uncertainty, dtype=np.float64), coverage, method="higher"))


def acceptance_indicator(uncertainty: np.ndarray, threshold: float) -> np.ndarray:
    return (np.asarray(uncertainty) <= threshold).astype(np.int8)
