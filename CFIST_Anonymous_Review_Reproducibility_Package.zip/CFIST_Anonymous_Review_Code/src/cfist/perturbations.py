from __future__ import annotations

import copy

import numpy as np


def delete_prefix_events(batch: dict, fraction: float, seed: int) -> dict:
    if not 0 <= fraction < 1:
        raise ValueError("fraction must be in [0, 1)")
    output = copy.deepcopy(batch)
    rng = np.random.default_rng(seed)
    for row in range(len(output["stage_ids"])):
        length = len(output["stage_ids"][row])
        retain = max(1, int(round(length * (1 - fraction))))
        selected = np.sort(rng.choice(length, size=retain, replace=False))
        for key in ("stage_ids", "item_codes", "gap_seconds", "elapsed_seconds", "relations"):
            values = np.asarray(output[key][row], dtype=object)
            output[key][row] = values[selected].tolist()
    return output


def add_timestamp_noise(batch: dict, scale_fraction: float, seed: int) -> dict:
    output = copy.deepcopy(batch)
    rng = np.random.default_rng(seed)
    for row, gaps in enumerate(output["gap_seconds"]):
        gap = np.asarray(gaps, dtype=np.float64)
        scale = scale_fraction * max(1.0, float(np.median(gap[gap > 0])) if np.any(gap > 0) else 1.0)
        output["gap_seconds"][row] = np.clip(gap + rng.normal(0.0, scale, size=len(gap)), 0, None).tolist()
    return output


def corrupt_stage_map(batch: dict, fraction: float, seed: int) -> dict:
    output = copy.deepcopy(batch)
    rng = np.random.default_rng(seed)
    for row, stages in enumerate(output["stage_ids"]):
        values = np.asarray(stages, dtype=np.int64)
        count = int(round(fraction * len(values)))
        if count:
            selected = rng.choice(len(values), size=count, replace=False)
            replacement = rng.integers(0, 3, size=count)
            values[selected] = replacement
        output["stage_ids"][row] = values.tolist()
    return output
