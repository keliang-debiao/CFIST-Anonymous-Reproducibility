from __future__ import annotations

import hashlib


def deterministic_include(identifier: str, fraction: float, seed: int) -> bool:
    if not 0 < fraction <= 1:
        raise ValueError("fraction must lie in (0, 1]")
    if fraction == 1:
        return True
    payload = f"{seed}:{identifier}".encode("utf-8")
    value = int.from_bytes(hashlib.blake2b(payload, digest_size=8).digest(), "big")
    return value / float(2**64 - 1) < fraction
