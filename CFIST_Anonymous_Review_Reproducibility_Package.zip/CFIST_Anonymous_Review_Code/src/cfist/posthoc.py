from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .calibration import TemperatureScaler, UncertaintyCombiner
from .uncertainty import RobustPrototypeSet, acceptance_indicator, acceptance_threshold


@dataclass
class FrozenPosthocState:
    temperature: TemperatureScaler
    prototypes: RobustPrototypeSet
    combiner: UncertaintyCombiner
    thresholds: dict[str, float]

    @classmethod
    def fit(
        cls,
        development: dict[str, np.ndarray],
        prototype_predictions: dict[str, np.ndarray],
        coverage_levels=(0.80, 1.00),
        uncertainty_mode: str = "dual",
    ):
        temperature = TemperatureScaler().fit(development["logit"], development["label"])
        calibrated = temperature.transform_probability(development["probability"])
        prototypes = RobustPrototypeSet.fit(
            prototype_predictions["representation"], prototype_predictions["environment"]
        )
        contextual = prototypes.distance(development["representation"])
        combiner = UncertaintyCombiner().fit(
            error_proxy=development["error_proxy"],
            prefix_length=development["prefix_length"],
            contextual_distance=contextual,
            probability=calibrated,
            labels=development["label"],
            mode=uncertainty_mode,
        )
        _, combined = combiner.transform(
            development["error_proxy"], development["prefix_length"], contextual
        )
        thresholds = {f"{coverage:.2f}": acceptance_threshold(combined, coverage) for coverage in coverage_levels}
        return cls(temperature, prototypes, combiner, thresholds)

    def transform(self, predictions: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
        calibrated = self.temperature.transform_probability(predictions["probability"])
        contextual = self.prototypes.distance(predictions["representation"])
        structural, combined = self.combiner.transform(
            predictions["error_proxy"], predictions["prefix_length"], contextual
        )
        output = dict(predictions)
        output["probability_calibrated"] = calibrated
        output["uncertainty_structural"] = structural
        output["uncertainty_contextual"] = contextual
        output["uncertainty_combined"] = combined
        for coverage, threshold in self.thresholds.items():
            output[f"accepted_{coverage}"] = acceptance_indicator(combined, threshold)
        return output

    def to_dict(self) -> dict:
        return {
            "temperature": self.temperature.to_dict(),
            "prototypes": self.prototypes.to_dict(),
            "combiner": self.combiner.to_dict(),
            "thresholds": self.thresholds,
        }

    @classmethod
    def from_dict(cls, payload: dict) -> "FrozenPosthocState":
        return cls(
            temperature=TemperatureScaler(**payload["temperature"]),
            prototypes=RobustPrototypeSet(**payload["prototypes"]),
            combiner=UncertaintyCombiner(**payload["combiner"]),
            thresholds={str(key): float(value) for key, value in payload["thresholds"].items()},
        )
