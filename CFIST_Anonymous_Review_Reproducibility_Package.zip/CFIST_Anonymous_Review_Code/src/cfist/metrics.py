from __future__ import annotations

import numpy as np
from scipy.optimize import minimize
from scipy.special import expit, logit
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score


def expected_calibration_error(labels, probability, bins: int = 15) -> float:
    y = np.asarray(labels, dtype=np.int64)
    p = np.asarray(probability, dtype=np.float64)
    edges = np.linspace(0.0, 1.0, bins + 1)
    index = np.minimum(np.digitize(p, edges[1:-1], right=True), bins - 1)
    ece = 0.0
    for bin_id in range(bins):
        mask = index == bin_id
        if not np.any(mask):
            continue
        ece += float(mask.mean()) * abs(float(y[mask].mean()) - float(p[mask].mean()))
    return float(ece)


def calibration_intercept_slope(labels, probability) -> tuple[float, float]:
    y = np.asarray(labels, dtype=np.float64)
    p = np.clip(np.asarray(probability, dtype=np.float64), 1e-7, 1 - 1e-7)
    x = logit(p)

    def objective(parameters):
        intercept, slope = parameters
        eta = intercept + slope * x
        return float(np.mean(np.logaddexp(0.0, eta) - y * eta))

    result = minimize(objective, np.array([0.0, 1.0]), method="BFGS")
    if not result.success and not np.isfinite(result.fun):
        raise RuntimeError(f"Calibration regression failed: {result.message}")
    return float(result.x[0]), float(result.x[1])


def binary_metrics(labels, probability, ece_bins: int = 15) -> dict[str, float]:
    y = np.asarray(labels, dtype=np.int64)
    p = np.asarray(probability, dtype=np.float64)
    intercept, slope = calibration_intercept_slope(y, p)
    return {
        "n": int(len(y)),
        "prevalence": float(y.mean()),
        "auprc": float(average_precision_score(y, p)),
        "auroc": float(roc_auc_score(y, p)),
        "brier": float(brier_score_loss(y, p)),
        "ece": expected_calibration_error(y, p, bins=ece_bins),
        "calibration_intercept": intercept,
        "calibration_slope": slope,
    }


def selective_brier(labels, probability, accepted) -> float:
    y = np.asarray(labels)
    p = np.asarray(probability)
    mask = np.asarray(accepted, dtype=bool)
    if not np.any(mask):
        return float("nan")
    return float(np.mean(np.square(y[mask] - p[mask])))


def risk_coverage_curve(labels, probability, uncertainty, points: int = 101):
    y = np.asarray(labels)
    p = np.asarray(probability)
    u = np.asarray(uncertainty)
    order = np.argsort(u, kind="stable")
    coverages = np.linspace(0.01, 1.0, points)
    risks = []
    for coverage in coverages:
        retained = order[: max(1, int(np.ceil(coverage * len(order))))]
        risks.append(float(np.mean(np.square(y[retained] - p[retained]))))
    return coverages, np.asarray(risks)


def risk_coverage_area(labels, probability, uncertainty, points: int = 101) -> float:
    coverage, risk = risk_coverage_curve(labels, probability, uncertainty, points)
    return float(np.trapezoid(risk, coverage))
