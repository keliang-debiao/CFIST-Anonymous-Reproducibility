from cfist.cohort import adjacent_prefix, construct_example
from cfist.schema import RawEvent


def events(stages):
    return [RawEvent(timestamp=100 + 10 * i, item_id=str(i % 2), stage=stage) for i, stage in enumerate(stages)]


def test_midpoint_label_uses_suffix_only():
    example, reason = construct_example(source="unit", entity_id="a", group_id="a", events=events(["click", "cart", "click", "order"]))
    assert reason == "eligible"
    assert example.label == 1
    assert example.stage_ids == [0, 1]


def test_prefix_order_is_excluded():
    example, reason = construct_example(source="unit", entity_id="b", group_id="b", events=events(["order", "click", "click", "click"]))
    assert example is None
    assert reason == "order_in_prefix"


def test_adjacent_prefix_removes_one_observed_event():
    example, _ = construct_example(source="unit", entity_id="c", group_id="c", events=events(["click", "click", "cart", "click", "click", "order"]))
    shorter = adjacent_prefix(example)
    assert shorter is not None
    assert shorter.prefix_length == example.prefix_length - 1
    assert len(shorter.stage_ids) == len(example.stage_ids) - 1
