import numpy as np
import pytest

from cfist.folds import assert_no_group_overlap, assign_blocks, equal_duration_boundaries, rolling_outer_fold, terminal_development_split


def test_rolling_fold_is_strictly_chronological():
    times = np.arange(60)
    blocks = assign_blocks(times, equal_duration_boundaries(times, 6))
    train, validation = rolling_outer_fold(blocks, 4)
    assert times[train].max() < times[validation].min()


def test_terminal_development_split_is_chronological():
    times = np.arange(100)
    fitting, development = terminal_development_split(times, np.arange(100), .10)
    assert len(fitting) == 90 and len(development) == 10
    assert times[fitting].max() < times[development].min()


def test_group_overlap_guard_fails_closed():
    groups = np.asarray(["a", "b", "b", "c"])
    with pytest.raises(AssertionError):
        assert_no_group_overlap(groups, np.asarray([0, 1]), np.asarray([2, 3]))
