from pathlib import Path
from statistics import mean, stdev

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]


def test_reported_fold_arithmetic():
    frame = pd.read_csv(ROOT / "records/results/cv_folds.csv")
    assert round(mean(frame.auprc), 3) == .487
    assert round(stdev(frame.auprc), 3) == .009
    assert round(mean(frame.auroc), 3) == .879
    assert round(stdev(frame.auroc), 3) == .006
    assert int(frame.eligible_sessions.sum()) == 7_090_394


def test_attribution_normalizes_to_one():
    frame = pd.read_csv(ROOT / "records/results/interpretability.csv")
    frame = frame[frame.diagnostic == "Normalized absolute attribution"]
    assert round(float(frame.estimate.sum()), 3) == 1.000


def test_external_configuration_is_primary_and_frozen():
    frame = pd.read_csv(ROOT / "records/results/external_validation.csv")
    primary = frame[frame.evaluation_set.str.contains("30 minutes")].iloc[0]
    assert int(primary.sessions) == 372_846
    assert float(primary.auprc) == .251
