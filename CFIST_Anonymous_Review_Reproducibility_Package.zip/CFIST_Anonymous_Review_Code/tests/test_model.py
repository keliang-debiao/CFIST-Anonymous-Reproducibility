import pytest

torch = pytest.importorskip("torch")

from cfist.model import CFIST


def test_forward_shapes_and_probability_range():
    model = CFIST(dim=32, layers=2, heads=4, local_window=4, max_length=6, graph_layers=2, dropout=0.0, ff_mult=2)
    batch = {
        "stage_ids": torch.tensor([[0, 1, 0], [0, 0, 1]]),
        "item_codes": torch.tensor([[0, 0, 1], [0, 1, 1]]),
        "gap_bins": torch.tensor([[0, 2, 1], [0, 1, 3]]),
        "relations": torch.rand(2, 3, 10),
        "attention_mask": torch.ones(2, 3, dtype=torch.bool),
        "graph_features": torch.rand(2, 9),
        "prefix_length": torch.tensor([3.0, 3.0]),
    }
    result = model(batch)
    assert result.purchase_logit.shape == (2,)
    assert result.representation.shape == (2, 32)
    assert torch.all((result.probability >= 0) & (result.probability <= 1))
